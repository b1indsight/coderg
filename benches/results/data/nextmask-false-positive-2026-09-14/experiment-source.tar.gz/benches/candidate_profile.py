#!/usr/bin/env python3
"""Profile candidate false positives and a resident nextMask feasibility filter.

Build with cargo build --release --locked --bench candidate_profile --bin coderg.
Use a fresh index and an immutable source snapshot outside the output directory.
"""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import random
import statistics
import subprocess
import sys
import time

sys.dont_write_bytecode = True
from regex_suite import QUERIES

CHROMIUM = [
    ("max_file_size", "fixed string", "MAX_FILE_SIZE", ["-F"]),
    ("weak_ptr_factory", "fixed string", "WeakPtrFactory", ["-F"]),
    ("icase_weak_ptr_factory", "ignore case", "WeakPtrFactory", ["-i", "-F"]),
    ("bind_once", "fixed string", "base::BindOnce", ["-F"]),
    ("histogram", "alternation", r"\bUmaHistogram(Boolean|Enumeration)\b", []),
    ("std_move", "alternation", r"\bstd::(move|forward)\(", []),
    ("check_macro", "character class", r"\bCHECK_[A-Z]+\(", []),
    ("class_decl", "anchor", r"^class[ \t]+\w+", []),
    ("todo_comment", "anchor / wildcard", r"^[ \t]*//.*\b(TODO|FIXME)\b", []),
    ("word_test", "word boundary", r"\btest\b", []),
    ("literal_test", "four-byte literal", "test", ["-F"]),
    ("literal_void", "four-byte literal", "void", ["-F"]),
    ("short_word", "scan fallback", r"\bif\b", []),
    ("absent", "no matches", "CODERG_DISTRIBUTION_ABSENT_92be7", ["-F"]),
]
EXTRA = [
    ("literal_cuda", "four-byte literal", "cuda", ["-F"]),
    ("literal_rocm", "four-byte literal", "rocm", ["-F"]),
    ("word_test", "word boundary", r"\btest\b", []),
    ("literal_test", "four-byte literal", "test", ["-F"]),
]


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def counts(stdout):
    result = {}
    for line in stdout.decode().splitlines():
        path, count = line.rsplit(":", 1)
        path = path.removeprefix("./")
        assert path not in result, path
        result[path] = int(count)
    return result


def summarize(report):
    result = {}
    for mode in ("baseline", "nextmask"):
        samples = [s for s in report["samples"] if s["mode"] == mode]
        stats = {k: statistics.median(s[k] for s in samples)
                 for k in samples[0] if k != "mode"}
        ratios = {
            "false_positive_pct": ("false_positive_files", "candidates"),
            "scan_wall_pct": ("scan_wall_ms", "total_ms"),
            "false_positive_match_work_pct": ("false_positive_match_worker_ms", "match_worker_ms"),
            "match_work_pct": ("match_worker_ms", None),
        }
        for key, (num, den) in ratios.items():
            values = []
            for s in samples:
                denominator = s[den] if den else s["read_worker_ms"] + s["match_worker_ms"]
                if denominator:
                    values.append(100 * s[num] / denominator)
            stats[key] = statistics.median(values) if values else None
        result[mode] = stats
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--suite", choices=["vllm", "chromium"], required=True)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--index-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--profiler", type=Path, required=True)
    parser.add_argument("--binary", type=Path, default=Path("target/release/coderg"))
    parser.add_argument("--iterations", type=int, default=9)
    parser.add_argument("--warmup", type=int, default=2)
    parser.add_argument("--resume", action="store_true", help="Reuse timings and revalidate parity")
    parser.add_argument("--reference-indexed-files", action="store_true",
                        help="Run rg --text on exactly the index's searchable files")
    args = parser.parse_args()
    root, out = args.root.resolve(), args.output.resolve()
    out.mkdir(parents=True, exist_ok=args.resume)
    repo = Path(__file__).resolve().parent.parent
    env = dict(os.environ, GIT_OPTIONAL_LOCKS="0")
    env.pop("RIPGREP_CONFIG_PATH", None)
    commands = json.loads((out / "commands.json").read_text()) if args.resume and (out / "commands.json").exists() else []
    previous_meta = json.loads((out / "metadata.json").read_text()) if args.resume else None
    previous_rows = {r["id"]: r for r in json.loads((out / "summary.json").read_text())} if args.resume else {}

    def run(command, capture=True, record=True):
        command = list(map(str, command))
        if record:
            commands.append(command)
        start = time.perf_counter_ns()
        p = subprocess.run(command, cwd=root, env=env, stdout=subprocess.PIPE if capture else subprocess.DEVNULL,
                           stderr=subprocess.PIPE)
        ms = (time.perf_counter_ns() - start) / 1e6
        assert p.returncode in (0, 1), (command, p.returncode, p.stderr.decode())
        assert not p.stderr, (command, p.stderr.decode())
        return p, ms

    def dump(name, value):
        (out / name).write_text(json.dumps(value, indent=2) + "\n")

    binary, profiler, index_dir = args.binary.resolve(), args.profiler.resolve(), args.index_dir.resolve()
    manifest_path = index_dir / "manifest.bin"
    indexed_paths = None
    if args.reference_indexed_files:
        paths_file = out / "indexed-files.json"
        if not paths_file.exists():
            p, _ = run([binary, "stats", ".", "--index-dir", index_dir, "--json"])
            manifest = json.loads(p.stdout)
            paths_file.write_text(json.dumps([d["path"] for d in manifest["documents"]
                                             if d["active"] and d["searchable"]]) + "\n")
            del p, manifest
        indexed_paths = json.loads(paths_file.read_text())
    meta = dict(started_utc=datetime.now(timezone.utc).isoformat(), platform=platform.platform(),
                iterations=args.iterations, warmup=args.warmup, logical_cpus=os.cpu_count(),
                environment={k: env.get(k) for k in ["RAYON_NUM_THREADS", "LANG", "LC_ALL"]},
                root=str(root), index_dir=str(index_dir), manifest_sha256=digest(manifest_path),
                binary_sha256=digest(binary), profiler_sha256=digest(profiler),
                source_sha256={str(p.relative_to(repo)): digest(p) for p in
                    [repo / "Cargo.toml", repo / "Cargo.lock", *sorted((repo / "src").glob("*.rs")),
                     Path(__file__), repo / "benches/candidate_profile.rs", repo / "benches/regex_suite.py"]},
                base_commit=subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=repo).decode().strip(),
                rg_version=subprocess.check_output(["rg", "--version"]).decode().strip())
    meta["reference_indexed_files"] = args.reference_indexed_files
    if indexed_paths is not None:
        meta["indexed_paths_sha256"] = digest(out / "indexed-files.json")
    if previous_meta:
        assert previous_meta["profiler_sha256"] == meta["profiler_sha256"]
        assert previous_meta["binary_sha256"] == meta["binary_sha256"]
        assert previous_meta["manifest_sha256"] == meta["manifest_sha256"]
        assert (previous_meta["iterations"], previous_meta["warmup"]) == (args.iterations, args.warmup)
        meta["previous_invocation"] = previous_meta
    dump("metadata.json", meta)
    queries = list(QUERIES) + EXTRA if args.suite == "vllm" else list(CHROMIUM)
    random.Random(20260914).shuffle(queries)
    results = []
    for query_id, category, pattern, flags in queries:
        report_path = out / f"{query_id}.json"
        profile_cmd = [profiler, "--root", root, "--index-dir", index_dir, "--pattern", pattern,
                       "--output", report_path, "--iterations", args.iterations, "--warmup", args.warmup, *flags]
        if not (args.resume and report_path.exists()):
            p, _ = run(profile_cmd)
            assert p.returncode == 0
        report = json.loads(report_path.read_text())
        cli = [binary, "search", "-c", *flags, pattern, ".", "--index-dir", index_dir, "--no-refresh"]
        rg = ["rg", "--no-config", "--encoding", "none", "-c", "-H", "--hidden", "--glob", "!.git/**", "--glob",
              "!.coderg-index/**", "--color", "never", "--no-heading", *flags, pattern, "."]
        parity = {}
        for name, cmd in [("coderg", cli), ("rg", rg)]:
            if name == "rg" and indexed_paths is not None:
                base = ["rg", "--no-config", "--encoding", "none", "--text", "--no-ignore",
                        "-c", "-H", "--color", "never", "--no-heading", *flags, "--", pattern]
                commands.append(dict(command=base, indexed_files="indexed-files.json",
                                     indexed_files_sha256=meta["indexed_paths_sha256"], batch_size=1000))
                actual = {}
                for offset in range(0, len(indexed_paths), 1000):
                    p, _ = run([*base, *indexed_paths[offset:offset + 1000]], record=False)
                    batch = counts(p.stdout)
                    assert not (actual.keys() & batch.keys())
                    actual.update(batch)
                exit_code = 0 if actual else 1
            else:
                p, _ = run(cmd)
                actual = counts(p.stdout)
                exit_code = p.returncode
            expected = report["matches"]
            if actual != expected:
                dump(query_id + "-parity-error.json", dict(actual=actual, expected=expected, tool=name))
            assert actual == expected, (query_id, name, "file/count parity failed")
            assert exit_code == (0 if expected else 1)
            parity[name] = dict(files=len(actual), lines=sum(actual.values()),
                                sha256=hashlib.sha256(json.dumps(actual, sort_keys=True).encode()).hexdigest())
        # Uninstrumented one-query-per-process baseline, after parity warmup.
        cli_samples = previous_rows.get(query_id, {}).get("cli_samples_ms", [])
        if not cli_samples:
            for round_index in range(args.warmup + args.iterations):
                _, ms = run(cli, capture=False)
                if round_index >= args.warmup:
                    cli_samples.append(ms)
        row = dict(id=query_id, category=category, pattern=pattern, flags=flags,
                   fallback=report["fallback"], mask_keys=len(report["mask_plan"]["keys"]),
                   mask_groups=len(report["mask_plan"]["groups"]),
                   summary=summarize(report), cli_samples_ms=cli_samples,
                   cli_median_ms=statistics.median(cli_samples), parity=parity)
        results.append(row)
        dump("summary.json", results)
        dump("commands.json", commands)
        b, n = row["summary"]["baseline"], row["summary"]["nextmask"]
        print(args.suite, query_id, "candidates", b["candidates"], "->", n["candidates"],
              "false positives", b["false_positive_files"], "scan ms", round(b["scan_wall_ms"], 3), flush=True)
    assert digest(manifest_path) == meta["manifest_sha256"], "index changed"
    meta["finished_utc"] = datetime.now(timezone.utc).isoformat()
    dump("metadata.json", meta)


if __name__ == "__main__":
    main()
