//! Diagnostic only: production candidate selection and line matching, plus an
//! optimistic resident nextMask experiment. No production index format changes.
#![allow(dead_code, unused_imports)]

#[path = "../src/build.rs"]
mod build;
#[path = "../src/compaction.rs"]
mod compaction;
#[path = "../src/git_state.rs"]
mod git_state;
#[path = "../src/index.rs"]
mod index;
#[path = "../src/manifest.rs"]
mod manifest;
#[path = "../src/segment.rs"]
mod segment;

mod ngram {
    include!("../src/ngram.rs");

    pub fn next_constraints(literal: &[u8]) -> Vec<([u8; 3], u8)> {
        let selected = covering_hashes(literal, crate::query::MAX_INDEX_LOOKUPS);
        covering_grams(literal)
            .into_iter()
            .filter(|g| g.len == 3 && selected.contains(&g.hash))
            .filter_map(|g| {
                literal
                    .get(g.start + 3)
                    .map(|&next| (literal[g.start..g.start + 3].try_into().unwrap(), next))
            })
            .collect()
    }
}

mod query {
    include!("../src/query.rs");

    pub fn profile_literals(pattern: &str, ignore_case: bool) -> Result<Vec<Vec<Vec<u8>>>> {
        let hir = ParserBuilder::new()
            .case_insensitive(ignore_case)
            .multi_line(true)
            .utf8(false)
            .build()
            .parse(pattern)?;
        Ok(required_literal_groups(&hir))
    }
}

mod search {
    include!("../src/search.rs");

    pub fn profile_candidates(
        index: &index::DiskIndex,
        plan: &[query::GramGroup],
    ) -> Result<Vec<u32>> {
        choose_candidates(index, plan)
    }

    pub fn profile_match(regex: &Regex, bytes: &[u8]) -> usize {
        let options = Options {
            ignore_case: false,
            fixed_strings: false,
            files_with_matches: false,
            count: true,
            max_count: None,
            no_refresh: true,
        };
        // The same full line scan as `coderg search -c`; no early exit and no
        // matching-line string allocation. Includes memchr line splitting.
        match_file(regex, bytes, Path::new(""), &options).1
    }
}

use std::{collections::BTreeMap, fs, path::PathBuf, time::Instant};

use anyhow::{Context, Result, ensure};
use clap::Parser;
use rayon::prelude::*;
use regex::bytes::{Regex, RegexBuilder};
use serde::Serialize;

#[derive(Parser)]
struct Args {
    #[arg(long)]
    root: PathBuf,
    #[arg(long)]
    index_dir: PathBuf,
    #[arg(long)]
    pattern: String,
    #[arg(short = 'i', long)]
    ignore_case: bool,
    #[arg(short = 'F', long)]
    fixed_strings: bool,
    #[arg(long, default_value_t = 9)]
    iterations: usize,
    #[arg(long, default_value_t = 2)]
    warmup: usize,
    #[arg(long)]
    output: PathBuf,
    #[arg(long, hide = true)]
    bench: bool,
}

fn elapsed_ms(start: Instant) -> f64 {
    start.elapsed().as_secs_f64() * 1000.0
}

fn next_bit(byte: u8) -> u8 {
    1 << (ngram::hash(&[byte]) & 7)
}

#[derive(Default, Serialize)]
struct MaskPlan {
    // Separate exact 24-bit trigram namespace: no alias with sparse gram hashes.
    keys: Vec<[u8; 3]>,
    // AND groups, OR literal branches, AND predicates within each branch.
    groups: Vec<Vec<Vec<(usize, u8)>>>,
}

impl MaskPlan {
    fn new(literals: Vec<Vec<Vec<u8>>>) -> Self {
        let mut plan = Self::default();
        for group in literals {
            let constraints: Vec<_> = group
                .iter()
                .map(|literal| ngram::next_constraints(literal))
                .collect();
            // An unconstrained OR branch must pass. Its entire mask group is
            // therefore uninformative, regardless of constraints in siblings.
            if constraints.is_empty() || constraints.iter().any(Vec::is_empty) {
                continue;
            }
            let mut branches = Vec::new();
            for branch in constraints {
                let mut predicates = Vec::new();
                for (key, next) in branch {
                    let slot = plan.keys.iter().position(|k| k == &key).unwrap_or_else(|| {
                        plan.keys.push(key);
                        plan.keys.len() - 1
                    });
                    predicates.push((slot, next_bit(next)));
                }
                branches.push(predicates);
            }
            plan.groups.push(branches);
        }
        plan
    }

    fn masks(&self, bytes: &[u8]) -> Vec<u8> {
        self.keys
            .iter()
            .map(|key| {
                let finder = memchr::memmem::Finder::new(key);
                let mut start = 0;
                let mut mask = 0;
                while let Some(offset) = finder.find(&bytes[start..]) {
                    let position = start + offset;
                    if let Some(&next) = bytes.get(position + 3) {
                        mask |= next_bit(next);
                    }
                    // Include overlapping occurrences, e.g. aaa in aaaab.
                    start = position + 1;
                    if mask == u8::MAX {
                        break;
                    }
                }
                mask
            })
            .collect()
    }

    fn accepts(&self, masks: &[u8]) -> bool {
        self.groups.iter().all(|group| {
            group
                .iter()
                .any(|branch| branch.iter().all(|&(slot, bit)| masks[slot] & bit != 0))
        })
    }
}

#[derive(Serialize)]
struct FileSample {
    id: u32,
    bytes: usize,
    matches: usize,
    read_ms: f64,
    match_ms: f64,
}

fn scan(index: &index::DiskIndex, ids: &[u32], regex: &Regex) -> Result<Vec<FileSample>> {
    ids.par_iter()
        .map_init(
            || regex.clone(),
            |regex, &id| {
                let doc = &index.manifest.documents[id as usize];
                let path = index.manifest.root.join(&doc.path);
                let read = Instant::now();
                let bytes =
                    fs::read(&path).with_context(|| format!("reading {}", path.display()))?;
                let read_ms = elapsed_ms(read);
                ensure!(
                    bytes.len() as u64 == doc.len,
                    "stale corpus: {}",
                    path.display()
                );
                let matching = Instant::now();
                let matches = search::profile_match(regex, &bytes);
                let match_ms = elapsed_ms(matching);
                Ok(FileSample {
                    id,
                    bytes: bytes.len(),
                    matches,
                    read_ms,
                    match_ms,
                })
            },
        )
        .collect()
}

#[derive(Default, Serialize)]
struct Sample {
    mode: &'static str,
    indexed_files: usize,
    candidates: usize,
    matched_files: usize,
    matched_lines: usize,
    false_positive_files: usize,
    candidate_bytes: usize,
    false_positive_bytes: usize,
    compile_ms: f64,
    load_ms: f64,
    plan_ms: f64,
    candidates_ms: f64,
    mask_filter_ms: f64,
    scan_wall_ms: f64,
    read_worker_ms: f64,
    match_worker_ms: f64,
    false_positive_read_worker_ms: f64,
    false_positive_match_worker_ms: f64,
    total_ms: f64,
}

fn strategies(pattern: &str, args: &Args) -> Result<Vec<query::GramGroup>> {
    if args.fixed_strings && !args.ignore_case {
        Ok(query::fixed_strategy(args.pattern.as_bytes()))
    } else {
        query::literal_strategies(pattern, args.ignore_case)
    }
}

fn run_sample(
    args: &Args,
    pattern: &str,
    masks: &MaskPlan,
    cached: &[Vec<u8>],
    expected_ids: &[u32],
    use_masks: bool,
) -> Result<(Sample, BTreeMap<String, usize>)> {
    let start = Instant::now();
    let mut sample = Sample {
        mode: if use_masks { "nextmask" } else { "baseline" },
        ..Default::default()
    };
    let phase = Instant::now();
    let regex = RegexBuilder::new(pattern)
        .case_insensitive(args.ignore_case)
        .multi_line(true)
        .build()?;
    sample.compile_ms = elapsed_ms(phase);
    let phase = Instant::now();
    let index = index::load(&args.root, Some(&args.index_dir))?;
    sample.load_ms = elapsed_ms(phase);
    let phase = Instant::now();
    let plan = strategies(pattern, args)?;
    sample.plan_ms = elapsed_ms(phase);
    let phase = Instant::now();
    let mut ids = search::profile_candidates(&index, &plan)?;
    sample.candidates_ms = elapsed_ms(phase);
    ensure!(
        ids == expected_ids,
        "candidate set changed during benchmark"
    );
    if use_masks {
        let phase = Instant::now();
        ids = ids
            .into_iter()
            .zip(cached)
            .filter_map(|(id, values)| masks.accepts(values).then_some(id))
            .collect();
        sample.mask_filter_ms = elapsed_ms(phase);
    }
    sample.candidates = ids.len();
    let phase = Instant::now();
    let files = scan(&index, &ids, &regex)?;
    sample.scan_wall_ms = elapsed_ms(phase);
    // Search phases through completion of candidate scanning, excluding stats,
    // output, object destruction, process startup, and refresh.
    sample.total_ms = elapsed_ms(start);
    sample.indexed_files = index.all_document_ids().len();
    let mut matches = BTreeMap::new();
    for f in files {
        sample.candidate_bytes += f.bytes;
        sample.read_worker_ms += f.read_ms;
        sample.match_worker_ms += f.match_ms;
        sample.matched_lines += f.matches;
        if f.matches == 0 {
            sample.false_positive_files += 1;
            sample.false_positive_bytes += f.bytes;
            sample.false_positive_read_worker_ms += f.read_ms;
            sample.false_positive_match_worker_ms += f.match_ms;
        } else {
            sample.matched_files += 1;
            matches.insert(
                index.manifest.documents[f.id as usize]
                    .path
                    .to_string_lossy()
                    .into_owned(),
                f.matches,
            );
        }
    }
    Ok((sample, matches))
}

fn self_check() -> Result<()> {
    let plan = MaskPlan {
        keys: vec![*b"aaa"],
        groups: vec![vec![vec![(0, next_bit(b'b'))]]],
    };
    ensure!(plan.accepts(&plan.masks(b"aaaab")), "overlap lost");
    ensure!(
        !plan.accepts(&plan.masks(b"aaa")),
        "EOF must not invent a next byte"
    );
    let all_bytes: Vec<u8> = (0..=255).flat_map(|b| [b'a', b'a', b'a', b]).collect();
    ensure!(
        plan.masks(&all_bytes)[0] == 255,
        "all next-byte bits must merge"
    );
    for pattern in [
        "abcd",
        "abcd|xyz",
        "abc.*d",
        "abcd?",
        "[ab]cde",
        "(?:abcd)?",
        "aaaab",
        "(?i)abcd",
        "éabcδ",
        "abcd|abce",
    ] {
        let regex = RegexBuilder::new(pattern).multi_line(true).build()?;
        let plan = MaskPlan::new(query::profile_literals(pattern, false)?);
        for bytes in [
            b"abcd".as_slice(),
            b"xyz",
            b"abc___d",
            b"abc",
            b"bcde",
            b"",
            b"aaaab",
            b"ABCD",
            "éabcδ".as_bytes(),
            b"abce",
        ] {
            if search::profile_match(&regex, bytes) > 0 {
                ensure!(
                    plan.accepts(&plan.masks(bytes)),
                    "mask dropped a true match for {pattern}"
                );
            }
        }
    }
    Ok(())
}

#[derive(Serialize)]
struct Report {
    pattern: String,
    fixed_strings: bool,
    ignore_case: bool,
    root: PathBuf,
    index_dir: PathBuf,
    threads: usize,
    fallback: bool,
    mask_plan: MaskPlan,
    mask_prepare_ms: f64,
    resident_mask_payload_bytes: usize,
    saturated_masks: usize,
    samples: Vec<Sample>,
    matches: BTreeMap<String, usize>,
}

fn main() -> Result<()> {
    let args = Args::parse();
    ensure!(args.iterations > 0, "iterations must be positive");
    self_check()?;
    let pattern = if args.fixed_strings {
        regex::escape(&args.pattern)
    } else {
        args.pattern.clone()
    };
    let index = index::load(&args.root, Some(&args.index_dir))?;
    let strategy = strategies(&pattern, &args)?;
    let ids = search::profile_candidates(&index, &strategy)?;
    let masks = MaskPlan::new(query::profile_literals(&pattern, args.ignore_case)?);
    let phase = Instant::now();
    // Query-specific metadata preparation is deliberately outside all search
    // timers. This measures filtering opportunity, not a complete index design.
    let cached: Vec<Vec<u8>> = ids
        .par_iter()
        .map(|&id| -> Result<_> {
            if masks.keys.is_empty() {
                return Ok(Vec::new());
            }
            let doc = &index.manifest.documents[id as usize];
            let bytes = fs::read(index.manifest.root.join(&doc.path))?;
            Ok(masks.masks(&bytes))
        })
        .collect::<Result<_>>()?;
    let mask_prepare_ms = elapsed_ms(phase);
    let saturated_masks = cached.iter().flatten().filter(|&&mask| mask == 255).count();
    drop(index);
    let mut samples = Vec::new();
    let mut expected = None;
    for round in 0..args.warmup + args.iterations {
        for use_masks in [round % 2 == 1, round % 2 == 0] {
            let (sample, matches) = run_sample(&args, &pattern, &masks, &cached, &ids, use_masks)?;
            if let Some(expected) = &expected {
                ensure!(
                    &matches == expected,
                    "matching files or counts changed across modes/rounds"
                );
            } else {
                expected = Some(matches);
            }
            if round >= args.warmup {
                samples.push(sample);
            }
        }
    }
    let report = Report {
        pattern: args.pattern,
        fixed_strings: args.fixed_strings,
        ignore_case: args.ignore_case,
        root: args.root,
        index_dir: args.index_dir,
        threads: rayon::current_num_threads(),
        fallback: strategy.is_empty()
            || strategy
                .iter()
                .all(|g| g.is_empty() || g.iter().any(Vec::is_empty)),
        resident_mask_payload_bytes: cached.iter().map(Vec::len).sum(),
        saturated_masks,
        mask_plan: masks,
        mask_prepare_ms,
        samples,
        matches: expected.unwrap(),
    };
    fs::write(args.output, serde_json::to_vec_pretty(&report)?)?;
    Ok(())
}
