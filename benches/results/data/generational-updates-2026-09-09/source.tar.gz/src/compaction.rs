//! Two generations: the first manifest segment is B; every other segment is M.
use std::{
    cmp::Reverse,
    collections::{BinaryHeap, HashSet},
    fs,
    path::Path,
};

use anyhow::{Context, Result};
use serde::Serialize;

use crate::{
    manifest::{Manifest, SegmentMeta},
    segment::{self, Records, Segment},
};

pub const MAX_MIDDLE_SEGMENTS: usize = 8;
const MAX_AUTO_INPUTS: usize = 4;
pub const MAX_AUTO_BYTES: u64 = 32 * 1024 * 1024;
pub const MAX_MANUAL_INPUTS: usize = 32;

#[derive(Debug, Default, Serialize)]
pub struct Summary {
    pub inputs: Vec<u64>,
    pub input_bytes: u64,
    pub output_bytes: u64,
    pub output: Option<u64>,
    pub full: bool,
}

pub fn bytes(directory: &Path, meta: &SegmentMeta) -> Result<u64> {
    Ok(fs::metadata(directory.join(&meta.lookup))?.len()
        + fs::metadata(directory.join(&meta.postings))?.len())
}

/// Discard dead M references, but keep the first segment as the stable B anchor.
/// Files remain immutable on disk so concurrent readers retain a valid snapshot.
pub fn prune(manifest: &mut Manifest) {
    let live: HashSet<_> = manifest
        .documents
        .iter()
        .filter(|doc| doc.active && doc.searchable)
        .map(|doc| doc.segment_id)
        .collect();
    let base = manifest.segments.first().map(|meta| meta.id);
    manifest
        .segments
        .retain(|meta| Some(meta.id) == base || live.contains(&meta.id));
}

pub fn automatic_plan(directory: &Path, manifest: &Manifest) -> Result<Vec<u64>> {
    if manifest.segments.len().saturating_sub(1) <= MAX_MIDDLE_SEGMENTS {
        return Ok(Vec::new());
    }
    let sizes = manifest
        .segments
        .iter()
        .skip(1)
        .enumerate()
        .map(|(order, meta)| Ok((bytes(directory, meta)?, order, meta.id)))
        .collect::<Result<Vec<_>>>()?;
    Ok(plan_sizes(sizes))
}

fn plan_sizes(mut sizes: Vec<(u64, usize, u64)>) -> Vec<u64> {
    sizes.sort_unstable();
    // Merge similarly sized inputs. Small new segments do not repeatedly drag a
    // large accumulated segment into every merge. Equal sizes prefer older M.
    for start in 0..sizes.len() {
        let mut total = 0_u64;
        let mut selected = Vec::new();
        for &(size, _, id) in sizes.iter().skip(start).take(MAX_AUTO_INPUTS) {
            if size > sizes[start].0.max(1).saturating_mul(4)
                || size > MAX_AUTO_BYTES.saturating_sub(total)
            {
                break;
            }
            selected.push(id);
            total += size;
        }
        if selected.len() >= 2 {
            return selected;
        }
    }
    Vec::new()
}

pub fn describe(directory: &Path, manifest: &Manifest, inputs: &[u64]) -> Result<Summary> {
    let mut summary = Summary {
        inputs: inputs.to_vec(),
        ..Summary::default()
    };
    summary.full = manifest
        .segments
        .first()
        .is_some_and(|base| inputs.contains(&base.id));
    for id in inputs {
        let meta = manifest
            .segments
            .iter()
            .find(|meta| meta.id == *id)
            .context("compaction input is absent from the manifest")?;
        summary.input_bytes += bytes(directory, meta)?;
    }
    Ok(summary)
}

pub fn merge(
    directory: &Path,
    manifest: &mut Manifest,
    inputs: &[u64],
    id: u64,
) -> Result<Summary> {
    let mut summary = describe(directory, manifest, inputs)?;
    let selected: HashSet<_> = inputs.iter().copied().collect();
    let segments = manifest
        .segments
        .iter()
        .filter(|meta| selected.contains(&meta.id))
        .map(|meta| segment::load(directory, meta))
        .collect::<Result<Vec<_>>>()?;
    // The existing encoder first writes postings and key metadata, so the final
    // key count is discovered after filtering, without a second decoding pass.
    let (output, _) =
        segment::write_partitioned(directory, id, 1, |_| Merged::new(&segments, manifest))?;
    summary.output_bytes = bytes(directory, &output)?;
    summary.output = Some(id);
    for document in &mut manifest.documents {
        if document.active && document.searchable && selected.contains(&document.segment_id) {
            document.segment_id = id;
        }
    }
    let position = manifest
        .segments
        .iter()
        .position(|meta| selected.contains(&meta.id))
        .context("empty compaction plan")?;
    manifest
        .segments
        .retain(|meta| !selected.contains(&meta.id));
    manifest.segments.insert(position, output);
    prune(manifest);
    Ok(summary)
}

struct Merged<'a> {
    cursors: Vec<Records<'a>>,
    ids: Vec<u64>,
    manifest: &'a Manifest,
    heap: BinaryHeap<Reverse<(u32, u32, usize)>>,
    previous: Option<(u32, u32)>,
    failed: bool,
}

impl<'a> Merged<'a> {
    fn new(segments: &'a [Segment], manifest: &'a Manifest) -> Result<Self> {
        let mut merged = Self {
            cursors: segments.iter().map(Segment::records).collect(),
            ids: segments.iter().map(|segment| segment.meta.id).collect(),
            manifest,
            heap: BinaryHeap::new(),
            previous: None,
            failed: false,
        };
        for cursor in 0..segments.len() {
            merged.advance(cursor)?;
        }
        Ok(merged)
    }

    fn advance(&mut self, cursor: usize) -> Result<()> {
        for record in &mut self.cursors[cursor] {
            let (key, id) = record?;
            let doc = self
                .manifest
                .documents
                .get(id as usize)
                .context("invalid document ID in compaction input")?;
            if doc.active && doc.searchable && doc.segment_id == self.ids[cursor] {
                self.heap.push(Reverse((key, id, cursor)));
                break;
            }
        }
        Ok(())
    }
}

impl Iterator for Merged<'_> {
    type Item = Result<(u32, u32)>;

    fn next(&mut self) -> Option<Self::Item> {
        if self.failed {
            return None;
        }
        while let Some(Reverse((key, id, cursor))) = self.heap.pop() {
            if let Err(error) = self.advance(cursor) {
                self.failed = true;
                return Some(Err(error));
            }
            if self.previous != Some((key, id)) {
                self.previous = Some((key, id));
                return Some(Ok((key, id)));
            }
        }
        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn automatic_work_has_byte_and_fan_in_limits_and_preserves_large_inputs() {
        let mut sizes = vec![(MAX_AUTO_BYTES * 2, 0, 1)];
        sizes.extend((2..12).map(|id| (1024, id as usize, id)));
        assert_eq!(plan_sizes(sizes), vec![2, 3, 4, 5]);
        assert!(plan_sizes(vec![(MAX_AUTO_BYTES, 0, 1), (MAX_AUTO_BYTES, 1, 2)]).is_empty());
        assert_eq!(
            plan_sizes(vec![(1, 0, 1), (1024, 1, 2), (1024, 2, 3)]),
            vec![2, 3]
        );
    }
}
