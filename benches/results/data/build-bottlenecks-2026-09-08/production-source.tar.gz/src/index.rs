use std::{
    collections::{BTreeSet, HashMap, HashSet},
    fs::{self, File},
    io::{BufWriter, Read, Write},
    path::{Path, PathBuf},
    sync::{
        Mutex,
        atomic::{AtomicUsize, Ordering},
        mpsc,
    },
    time::{SystemTime, UNIX_EPOCH},
};

use anyhow::{Context, Result, bail};
use ignore::{DirEntry, WalkBuilder, WalkState};
use rayon::prelude::*;
use serde::{Deserialize, Serialize};

use crate::{
    build::{CHUNK_BYTES, MemoryBudget, PostingsBuilder},
    git_state, ngram, segment,
};

const VERSION: u32 = 4;
const MAX_SEGMENTS: usize = 8;
const MIN_LARGE_CHANGE: usize = 64;
// Small snapshots do not amortize the parallel walker's worker startup and
// shutdown costs. This hint only selects how to walk; every file is checked.
const MAX_SERIAL_WALK_FILES: usize = 512;

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Manifest {
    version: u32,
    pub root: PathBuf,
    generation: u64,
    git_repository: bool,
    git_head: Option<String>,
    pub git_tree: Option<String>,
    source_state: Vec<FileState>,
    pub documents: Vec<Document>,
    pub segments: Vec<segment::SegmentMeta>,
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
struct FileState {
    path: PathBuf,
    len: u64,
    modified_nanos: u128,
}

// Each walker owns its batch and publishes it once, when traversal finishes.
// File metadata checks must not contend on a shared lock for every file.
struct FileCollector<'a> {
    root: &'a Path,
    batches: &'a Mutex<Vec<Result<Vec<FileState>>>>,
    files: Result<Vec<FileState>>,
}

impl FileCollector<'_> {
    fn visit(&mut self, entry: std::result::Result<DirEntry, ignore::Error>) -> WalkState {
        let state = entry
            .map_err(anyhow::Error::from)
            .and_then(|entry| file_state(self.root, &entry));
        match state {
            Ok(Some(state)) => {
                if let Ok(files) = &mut self.files {
                    files.push(state);
                }
            }
            Ok(None) => {}
            Err(error) => {
                self.files = Err(error);
                return WalkState::Quit;
            }
        }
        WalkState::Continue
    }
}

impl Drop for FileCollector<'_> {
    fn drop(&mut self) {
        self.batches
            .lock()
            .unwrap()
            .push(std::mem::replace(&mut self.files, Ok(Vec::new())));
    }
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Document {
    pub path: PathBuf,
    pub len: u64,
    modified_nanos: u128,
    pub active: bool,
    pub searchable: bool,
    pub segment_id: u64,
}

pub struct BuildSummary {
    pub files: usize,
    pub bytes: u64,
    pub ngrams: usize,
    pub index_dir: PathBuf,
}

pub struct Stats {
    pub root: PathBuf,
    pub files: usize,
    pub source_bytes: u64,
    pub ngrams: u64,
    pub index_bytes: u64,
    pub segments: usize,
    pub git_tree: Option<String>,
}

pub enum RefreshOutcome {
    Unchanged,
    CommitAdvanced,
    Incremental { changed: usize },
    SwitchedToCachedTree,
    Rebuilt,
}

pub struct DiskIndex {
    pub manifest: Manifest,
    segments: Vec<segment::Segment>,
}

struct IndexedFile {
    id: u32,
    state: FileState,
    searchable: bool,
}

pub fn resolve_root(path: &Path) -> Result<PathBuf> {
    path.canonicalize()
        .with_context(|| format!("cannot access search root {}", path.display()))
}

pub fn resolve_index_dir(root: &Path, requested: Option<&Path>) -> PathBuf {
    match requested {
        Some(path) if path.is_absolute() => path.to_path_buf(),
        Some(path) => root.join(path),
        None => root.join(".coderg-index"),
    }
}

pub fn build(
    path: &Path,
    requested_index_dir: Option<&Path>,
    budget: MemoryBudget,
) -> Result<BuildSummary> {
    let root = resolve_root(path)?;
    let index_dir = resolve_index_dir(&root, requested_index_dir);
    prepare_index_dir(&root, &index_dir)?;
    let source_state = collect_files(&root, &index_dir, None)?;
    let repository_state = git_state::inspect(&root, &index_dir)?;
    let segment_id = next_segment_id(&index_dir);
    let (indexed, segment) = index_files(
        &root,
        &index_dir,
        segment_id,
        budget,
        source_state
            .iter()
            .cloned()
            .enumerate()
            .map(|(id, state)| (id as u32, state)),
    )?;
    let ngrams = segment.ngrams as usize;
    let documents = indexed
        .iter()
        .map(|file| Document {
            path: file.state.path.clone(),
            len: file.state.len,
            modified_nanos: file.state.modified_nanos,
            active: true,
            searchable: file.searchable,
            segment_id,
        })
        .collect();
    let manifest = Manifest {
        version: VERSION,
        root: root.clone(),
        generation: 1,
        git_repository: repository_state.is_some(),
        git_head: repository_state
            .as_ref()
            .and_then(|state| state.head.clone()),
        git_tree: repository_state
            .as_ref()
            .and_then(|state| state.tree.clone()),
        source_state,
        documents,
        segments: vec![segment],
    };
    write_manifest(&index_dir, &manifest)?;
    cache_manifest_if_clean(
        &index_dir,
        &manifest,
        repository_state.is_some_and(|state| state.clean),
    )?;
    Ok(BuildSummary {
        files: manifest
            .documents
            .iter()
            .filter(|document| document.searchable)
            .count(),
        bytes: searchable_bytes(&manifest),
        ngrams,
        index_dir,
    })
}

pub fn refresh(
    index: &DiskIndex,
    requested_index_dir: Option<&Path>,
    budget: MemoryBudget,
) -> Result<RefreshOutcome> {
    let root = &index.manifest.root;
    let index_dir = resolve_index_dir(root, requested_index_dir);

    // Most searches stay on the same commit. In that case the persisted file
    // snapshot is enough to detect worktree changes, avoiding a full Git status
    // walk. A changed commit still uses status below because clean tree-cache
    // switching requires an authoritative Git answer.
    if index.manifest.git_repository
        && let Some(identity) = git_state::identity(root)?
        && identity.head == index.manifest.git_head
        && identity.tree == index.manifest.git_tree
    {
        let current_state =
            collect_files(root, &index_dir, Some(index.manifest.source_state.len()))?;
        if current_state == index.manifest.source_state {
            return Ok(RefreshOutcome::Unchanged);
        }
        let changed = changed_file_count(&index.manifest.source_state, &current_state);
        let large_change =
            changed >= MIN_LARGE_CHANGE && changed.saturating_mul(5) > current_state.len().max(1);
        if index.manifest.segments.len() >= MAX_SEGMENTS || large_change {
            build(root, requested_index_dir, budget)?;
            return Ok(RefreshOutcome::Rebuilt);
        }
        write_incremental(
            index,
            &index_dir,
            current_state,
            (identity.head, identity.tree),
            None,
            false,
            budget,
        )?;
        return Ok(RefreshOutcome::Incremental { changed });
    }

    let repository_state = if index.manifest.git_repository {
        git_state::inspect(root, &index_dir)?
    } else {
        None
    };
    let current_head = repository_state
        .as_ref()
        .and_then(|state| state.head.clone());
    let current_tree = repository_state
        .as_ref()
        .and_then(|state| state.tree.clone());

    if repository_state.as_ref().is_some_and(|state| state.clean) {
        if current_head == index.manifest.git_head && current_tree == index.manifest.git_tree {
            return Ok(RefreshOutcome::Unchanged);
        }
        if current_tree != index.manifest.git_tree
            && current_tree.is_some()
            && restore_cached_tree(
                index,
                &index_dir,
                current_head.as_deref(),
                current_tree.as_deref(),
            )?
        {
            return Ok(RefreshOutcome::SwitchedToCachedTree);
        }
        if current_tree == index.manifest.git_tree {
            let mut manifest = index.manifest.clone();
            manifest.generation += 1;
            manifest.git_head = current_head;
            write_manifest(&index_dir, &manifest)?;
            cache_manifest_if_clean(&index_dir, &manifest, true)?;
            return Ok(RefreshOutcome::CommitAdvanced);
        }
    }

    let current_state = collect_files(root, &index_dir, Some(index.manifest.source_state.len()))?;
    if current_state == index.manifest.source_state {
        if current_head == index.manifest.git_head && current_tree == index.manifest.git_tree {
            return Ok(RefreshOutcome::Unchanged);
        }
        let mut manifest = index.manifest.clone();
        manifest.generation += 1;
        manifest.git_head = current_head;
        manifest.git_tree = current_tree;
        write_manifest(&index_dir, &manifest)?;
        cache_manifest_if_clean(
            &index_dir,
            &manifest,
            repository_state.as_ref().is_some_and(|state| state.clean),
        )?;
        return Ok(RefreshOutcome::CommitAdvanced);
    }

    let known_changed = repository_state
        .as_ref()
        .filter(|state| !state.clean)
        .and_then(|state| state.changed_paths.as_ref());
    let changed = known_changed.map_or_else(
        || changed_file_count(&index.manifest.source_state, &current_state),
        HashSet::len,
    );
    let large_change =
        changed >= MIN_LARGE_CHANGE && changed.saturating_mul(5) > current_state.len().max(1);
    if index.manifest.segments.len() >= MAX_SEGMENTS || large_change {
        build(root, requested_index_dir, budget)?;
        return Ok(RefreshOutcome::Rebuilt);
    }
    write_incremental(
        index,
        &index_dir,
        current_state,
        (current_head, current_tree),
        known_changed,
        repository_state.as_ref().is_some_and(|state| state.clean),
        budget,
    )?;
    Ok(RefreshOutcome::Incremental { changed })
}

fn write_incremental(
    index: &DiskIndex,
    index_dir: &Path,
    current_state: Vec<FileState>,
    (current_head, current_tree): (Option<String>, Option<String>),
    known_changed: Option<&HashSet<PathBuf>>,
    cache_clean: bool,
    budget: MemoryBudget,
) -> Result<()> {
    let mut manifest = index.manifest.clone();
    let old_states: HashMap<&Path, &FileState> = manifest
        .source_state
        .iter()
        .map(|state| (state.path.as_path(), state))
        .collect();
    let current_paths: HashSet<&Path> = current_state
        .iter()
        .map(|state| state.path.as_path())
        .collect();
    let mut active_by_path: HashMap<PathBuf, u32> = manifest
        .documents
        .iter()
        .enumerate()
        .filter(|(_, document)| document.active)
        .map(|(id, document)| (document.path.clone(), id as u32))
        .collect();

    for document in &mut manifest.documents {
        if document.active && !current_paths.contains(document.path.as_path()) {
            document.active = false;
        }
    }
    let mut pending = Vec::new();
    for state in &current_state {
        let unchanged = match known_changed {
            Some(changed) => {
                old_states.contains_key(state.path.as_path()) && !changed.contains(&state.path)
            }
            None => old_states
                .get(state.path.as_path())
                .is_some_and(|old| *old == state),
        };
        if unchanged {
            continue;
        }
        let id = match active_by_path.get(&state.path) {
            Some(&id) => id,
            None => {
                let id = u32::try_from(manifest.documents.len())
                    .context("too many documents for a u32 document ID")?;
                manifest.documents.push(Document {
                    path: state.path.clone(),
                    len: state.len,
                    modified_nanos: state.modified_nanos,
                    active: true,
                    searchable: false,
                    segment_id: 0,
                });
                active_by_path.insert(state.path.clone(), id);
                id
            }
        };
        pending.push((id, state.clone()));
    }

    if !pending.is_empty() {
        let segment_id = next_segment_id(index_dir);
        let (indexed, segment) =
            index_files(&manifest.root, index_dir, segment_id, budget, pending)?;
        for file in indexed {
            let document = &mut manifest.documents[file.id as usize];
            document.path = file.state.path;
            document.len = file.state.len;
            document.modified_nanos = file.state.modified_nanos;
            document.active = true;
            document.searchable = file.searchable;
            document.segment_id = segment_id;
        }
        manifest.segments.push(segment);
    }
    manifest.generation += 1;
    manifest.git_head = current_head;
    manifest.git_tree = current_tree;
    manifest.source_state = current_state;
    write_manifest(index_dir, &manifest)?;
    cache_manifest_if_clean(index_dir, &manifest, cache_clean)?;
    Ok(())
}

fn index_files<I>(
    root: &Path,
    index_dir: &Path,
    segment_id: u64,
    budget: MemoryBudget,
    files: I,
) -> Result<(Vec<IndexedFile>, segment::SegmentMeta)>
where
    I: IntoIterator<Item = (u32, FileState)>,
{
    let files: Vec<_> = files.into_iter().collect();
    let workers = budget.workers(files.len());
    let mut postings = PostingsBuilder::new(index_dir, budget.record_bytes(workers));
    let mut searchable = vec![false; files.len()];
    let next_file = AtomicUsize::new(0);
    std::thread::scope(|scope| -> Result<()> {
        let (sender, receiver) = mpsc::sync_channel(workers);
        for _ in 0..workers {
            let sender = sender.clone();
            let files = &files;
            let next_file = &next_file;
            // Separate producers let the collector use Rayon's parallel sort
            // without blocking Rayon workers on a full channel or a mutex.
            scope.spawn(move || {
                loop {
                    let position = next_file.fetch_add(1, Ordering::Relaxed);
                    let Some((_, state)) = files.get(position) else {
                        break;
                    };
                    let path = root.join(&state.path);
                    let result = hash_file_chunks(&path, |hashes| {
                        sender
                            .send(Ok((position, hashes)))
                            .map_err(|_| anyhow::anyhow!("index build cancelled"))
                    });
                    if let Err(error) = result {
                        let _ = sender.send(Err(error));
                        break;
                    }
                }
            });
        }
        drop(sender);
        for batch in receiver {
            let (position, hashes) = batch?;
            searchable[position] = true;
            postings.extend(files[position].0, &hashes)?;
        }
        Ok(())
    })?;
    let segment = postings.write(segment_id)?;
    let indexed = files
        .into_iter()
        .zip(searchable)
        .map(|((id, state), searchable)| IndexedFile {
            id,
            state,
            searchable,
        })
        .collect();
    Ok((indexed, segment))
}

fn hash_file_chunks(
    path: &Path,
    mut emit: impl FnMut(Vec<ngram::GramHash>) -> Result<()>,
) -> Result<()> {
    let mut file = File::open(path).with_context(|| format!("cannot read {}", path.display()))?;
    let mut bytes = [0; CHUNK_BYTES];
    let mut retained = 0;
    loop {
        let mut len = retained;
        while len < bytes.len() {
            match file.read(&mut bytes[len..]) {
                Ok(0) => break,
                Ok(count) => len += count,
                Err(error) if error.kind() == std::io::ErrorKind::Interrupted => continue,
                Err(error) => {
                    return Err(error).with_context(|| format!("cannot read {}", path.display()));
                }
            }
        }
        if retained == 0 && is_binary(&bytes[..len]) {
            return Ok(());
        }
        if retained > 0 && len == retained {
            break;
        }
        emit(
            ngram::hashes_for_document(&bytes[..len])
                .into_iter()
                .collect(),
        )?;
        if len < bytes.len() {
            break;
        }
        // The predicate for any gram depends only on its own bytes. Retaining
        // MAX_GRAM - 1 bytes preserves every gram spanning a chunk boundary.
        retained = ngram::MAX_GRAM - 1;
        bytes.copy_within(len - retained..len, 0);
    }
    Ok(())
}

pub fn load(path: &Path, requested_index_dir: Option<&Path>) -> Result<DiskIndex> {
    let root = resolve_root(path)?;
    let index_dir = resolve_index_dir(&root, requested_index_dir);
    let manifest = read_manifest(&index_dir.join("manifest.json"))
        .with_context(|| "index not found; run `coderg index` or omit --no-refresh")?;
    if manifest.version != VERSION || manifest.root != root {
        bail!("index format or root mismatch; rebuild the index");
    }
    let segments = manifest
        .segments
        .iter()
        .map(|meta| segment::load(&index_dir, meta))
        .collect::<Result<_>>()?;
    Ok(DiskIndex { manifest, segments })
}

impl DiskIndex {
    pub fn postings(&self, hash: ngram::GramHash) -> Result<Vec<u32>> {
        let mut current = BTreeSet::new();
        for segment in &self.segments {
            for id in segment.postings(hash)? {
                let Some(document) = self.manifest.documents.get(id as usize) else {
                    bail!("segment contains an invalid document ID; rebuild the index");
                };
                if document.active && document.searchable && document.segment_id == segment.meta.id
                {
                    current.insert(id);
                }
            }
        }
        Ok(current.into_iter().collect())
    }

    pub fn all_document_ids(&self) -> Vec<u32> {
        self.manifest
            .documents
            .iter()
            .enumerate()
            .filter(|(_, document)| document.active && document.searchable)
            .map(|(id, _)| id as u32)
            .collect()
    }
}

fn restore_cached_tree(
    current: &DiskIndex,
    index_dir: &Path,
    head: Option<&str>,
    tree: Option<&str>,
) -> Result<bool> {
    let Some(tree) = tree else {
        return Ok(false);
    };
    let cache_path = index_dir.join("manifests").join(format!("{tree}.json"));
    if !cache_path.is_file() {
        return Ok(false);
    }
    let mut cached = read_manifest(&cache_path)?;
    if cached.version != VERSION || cached.root != current.manifest.root {
        return Ok(false);
    }
    cached.generation = current.manifest.generation + 1;
    cached.git_head = head.map(str::to_owned);
    cached.git_tree = Some(tree.to_owned());
    // Checkout/reset commonly changes mtimes even when the cached Git tree is
    // byte-for-byte identical. Rebase the metadata snapshot so the next search
    // does not create a redundant overlay segment.
    let source_state = collect_files(&cached.root, index_dir, Some(cached.source_state.len()))?;
    let state_by_path: HashMap<&Path, &FileState> = source_state
        .iter()
        .map(|state| (state.path.as_path(), state))
        .collect();
    for document in &mut cached.documents {
        if let Some(state) = state_by_path.get(document.path.as_path()) {
            document.len = state.len;
            document.modified_nanos = state.modified_nanos;
        }
    }
    cached.source_state = source_state;
    write_manifest(index_dir, &cached)?;
    Ok(true)
}

fn cache_manifest_if_clean(index_dir: &Path, manifest: &Manifest, clean: bool) -> Result<()> {
    let Some(tree) = &manifest.git_tree else {
        return Ok(());
    };
    if !clean {
        return Ok(());
    }
    let manifests_dir = index_dir.join("manifests");
    fs::create_dir_all(&manifests_dir)?;
    write_manifest_file(&manifests_dir.join(format!("{tree}.json")), manifest)
}

fn read_manifest(path: &Path) -> Result<Manifest> {
    // Parsing a slice avoids the per-byte Read overhead of serde's reader
    // adapter. The temporary JSON buffer is released before walking the tree.
    Ok(serde_json::from_slice(&fs::read(path)?)?)
}

fn write_manifest(index_dir: &Path, manifest: &Manifest) -> Result<()> {
    write_manifest_file(&index_dir.join("manifest.json"), manifest)
}

fn write_manifest_file(path: &Path, manifest: &Manifest) -> Result<()> {
    let tmp = path.with_extension("json.tmp");
    let mut file = BufWriter::new(File::create(&tmp)?);
    serde_json::to_writer_pretty(&mut file, manifest)?;
    file.flush()?;
    replace(tmp, path.to_path_buf())
}

fn replace(from: PathBuf, to: PathBuf) -> Result<()> {
    if cfg!(windows) && to.exists() {
        fs::remove_file(&to)?;
    }
    fs::rename(&from, &to).with_context(|| format!("cannot replace {}", to.display()))
}

fn prepare_index_dir(root: &Path, index_dir: &Path) -> Result<()> {
    if index_dir == root {
        bail!("the index directory cannot be the search root");
    }
    fs::create_dir_all(index_dir).with_context(|| format!("cannot create {}", index_dir.display()))
}

fn next_segment_id(index_dir: &Path) -> u64 {
    let mut id = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_nanos() as u64;
    while index_dir
        .join("segments")
        .join(format!("{id:020}.lookup"))
        .exists()
    {
        id = id.wrapping_add(1);
    }
    id
}

fn collect_files(
    root: &Path,
    index_dir: &Path,
    previous_file_count: Option<usize>,
) -> Result<Vec<FileState>> {
    let mut builder = WalkBuilder::new(root);
    builder.hidden(false).follow_links(false).filter_entry({
        let index_dir = index_dir.to_path_buf();
        move |entry| should_visit(entry, &index_dir)
    });
    if let Some(file_count) = previous_file_count.filter(|&count| count <= MAX_SERIAL_WALK_FILES) {
        let mut files = Vec::with_capacity(file_count);
        for entry in builder.build() {
            if let Some(state) = file_state(root, &entry?)? {
                files.push(state);
            }
        }
        files.sort_unstable_by(|left, right| left.path.cmp(&right.path));
        return Ok(files);
    }
    builder.threads(rayon::current_num_threads());
    let batches = Mutex::new(Vec::new());
    builder.build_parallel().run(|| {
        let mut collector = FileCollector {
            root,
            batches: &batches,
            files: Ok(Vec::new()),
        };
        Box::new(move |entry| collector.visit(entry))
    });
    let batches = batches
        .into_inner()
        .unwrap()
        .into_iter()
        .collect::<Result<Vec<_>>>()?;
    let mut files = Vec::with_capacity(batches.iter().map(Vec::len).sum());
    for batch in batches {
        files.extend(batch);
    }
    files.par_sort_unstable_by(|left, right| left.path.cmp(&right.path));
    Ok(files)
}

fn file_state(root: &Path, entry: &DirEntry) -> Result<Option<FileState>> {
    if !entry.file_type().is_some_and(|kind| kind.is_file()) {
        return Ok(None);
    }
    let metadata = entry.metadata()?;
    let modified_nanos = metadata
        .modified()
        .ok()
        .and_then(|time| time.duration_since(UNIX_EPOCH).ok())
        .map_or(0, |duration| duration.as_nanos());
    Ok(Some(FileState {
        path: entry.path().strip_prefix(root)?.to_path_buf(),
        len: metadata.len(),
        modified_nanos,
    }))
}

fn should_visit(entry: &DirEntry, index_dir: &Path) -> bool {
    entry.path() != index_dir && entry.file_name() != ".git"
}

fn changed_file_count(old: &[FileState], current: &[FileState]) -> usize {
    let old: HashMap<&Path, &FileState> = old
        .iter()
        .map(|state| (state.path.as_path(), state))
        .collect();
    let current_paths: HashSet<&Path> = current.iter().map(|state| state.path.as_path()).collect();
    let changed = current
        .iter()
        .filter(|state| {
            old.get(state.path.as_path())
                .is_none_or(|prior| *prior != *state)
        })
        .count();
    changed
        + old
            .keys()
            .filter(|path| !current_paths.contains(**path))
            .count()
}

fn is_binary(bytes: &[u8]) -> bool {
    bytes.iter().take(8192).any(|&byte| byte == 0)
}

fn searchable_bytes(manifest: &Manifest) -> u64 {
    manifest
        .documents
        .iter()
        .filter(|document| document.active && document.searchable)
        .map(|document| document.len)
        .sum()
}

pub fn stats(path: &Path, requested_index_dir: Option<&Path>) -> Result<Stats> {
    let index = load(path, requested_index_dir)?;
    let index_dir = resolve_index_dir(&index.manifest.root, requested_index_dir);
    let mut index_bytes = fs::metadata(index_dir.join("manifest.json"))?.len();
    for segment in &index.manifest.segments {
        index_bytes += fs::metadata(index_dir.join(&segment.lookup))?.len();
        index_bytes += fs::metadata(index_dir.join(&segment.postings))?.len();
    }
    Ok(Stats {
        root: index.manifest.root.clone(),
        files: index
            .manifest
            .documents
            .iter()
            .filter(|document| document.active && document.searchable)
            .count(),
        source_bytes: searchable_bytes(&index.manifest),
        ngrams: index
            .manifest
            .segments
            .iter()
            .map(|segment| segment.ngrams)
            .sum(),
        index_bytes,
        segments: index.manifest.segments.len(),
        git_tree: index.manifest.git_tree.clone(),
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn chunked_hashes_match_whole_files_including_boundaries() {
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("source");
        let mut random = 12345_u32;
        let bytes: Vec<_> = (0..CHUNK_BYTES * 5 + 17)
            .map(|_| {
                random ^= random << 13;
                random ^= random >> 17;
                random ^= random << 5;
                (random % 255 + 1) as u8
            })
            .collect();
        for len in [
            0,
            1,
            2,
            3,
            24,
            CHUNK_BYTES - 1,
            CHUNK_BYTES,
            CHUNK_BYTES + 1,
            bytes.len(),
        ] {
            fs::write(&path, &bytes[..len]).unwrap();
            let mut actual = ngram::GramHashSet::default();
            let mut batches = 0;
            hash_file_chunks(&path, |hashes| {
                actual.extend(hashes);
                batches += 1;
                Ok(())
            })
            .unwrap();
            assert!(batches >= 1, "even an empty text file is searchable");
            assert_eq!(
                actual,
                ngram::hashes_for_document(&bytes[..len]),
                "length {len}"
            );
        }
        for nul_position in [0, 8191, 8192, CHUNK_BYTES + 1] {
            let mut bytes = bytes.clone();
            bytes[nul_position] = 0;
            fs::write(&path, &bytes).unwrap();
            let mut actual = ngram::GramHashSet::default();
            hash_file_chunks(&path, |hashes| {
                actual.extend(hashes);
                Ok(())
            })
            .unwrap();
            if nul_position < 8192 {
                assert!(actual.is_empty());
            } else {
                assert_eq!(actual, ngram::hashes_for_document(&bytes));
            }
        }
    }

    #[test]
    fn read_failure_keeps_published_index_and_cancels_workers() {
        let directory = tempfile::tempdir().unwrap();
        let manifest = directory.path().join("manifest.json");
        fs::write(&manifest, "previous manifest").unwrap();
        let result = index_files(
            directory.path(),
            directory.path(),
            1,
            "16".parse().unwrap(),
            (0..100).map(|id| (id, state(&format!("missing-{id}"), 0))),
        );
        assert!(result.is_err());
        assert_eq!(fs::read_to_string(manifest).unwrap(), "previous manifest");
        assert_eq!(fs::read_dir(directory.path()).unwrap().count(), 1);
    }

    #[test]
    fn serial_and_parallel_snapshots_agree_even_with_a_stale_size_hint() {
        let root = tempfile::tempdir().unwrap();
        let index_dir = root.path().join("custom-index");
        for directory in [".git", "custom-index", ".hidden", "nested"] {
            fs::create_dir(root.path().join(directory)).unwrap();
        }
        fs::write(root.path().join(".ignore"), "*.skip\n!keep.skip\n").unwrap();
        for path in [
            ".git/config",
            "custom-index/manifest.json",
            ".hidden/source.rs",
            "nested/source.rs",
            "nested/hidden.skip",
            "nested/keep.skip",
        ] {
            fs::write(root.path().join(path), "contents\n").unwrap();
        }
        // The old snapshot can be tiny even after a large directory is added.
        for number in 0..600 {
            fs::write(root.path().join(format!("nested/{number:04}.rs")), "x\n").unwrap();
        }
        #[cfg(unix)]
        {
            std::os::unix::fs::symlink("nested", root.path().join("linked-dir")).unwrap();
            std::os::unix::fs::symlink("nested/source.rs", root.path().join("linked-file"))
                .unwrap();
        }

        let serial = collect_files(root.path(), &index_dir, Some(0)).unwrap();
        let parallel = collect_files(root.path(), &index_dir, None).unwrap();
        assert_eq!(serial, parallel);
        assert_eq!(serial.len(), 604);
        let paths: Vec<_> = serial.iter().map(|file| file.path.as_path()).collect();
        assert!(paths.contains(&Path::new(".hidden/source.rs")));
        assert!(paths.contains(&Path::new("nested/keep.skip")));
        assert!(!paths.contains(&Path::new("nested/hidden.skip")));

        let missing = root.path().join("missing");
        assert!(collect_files(&missing, &index_dir, Some(0)).is_err());
        assert!(collect_files(&missing, &index_dir, None).is_err());
    }

    #[test]
    fn counts_added_changed_and_deleted_files() {
        let old = vec![state("a", 1), state("b", 2), state("gone", 3)];
        let current = vec![state("a", 1), state("b", 4), state("new", 1)];
        assert_eq!(changed_file_count(&old, &current), 3);
    }

    fn state(path: &str, len: u64) -> FileState {
        FileState {
            path: PathBuf::from(path),
            len,
            modified_nanos: 0,
        }
    }
}
