//! Bounded posting buffers and external sorting for index construction.
use std::{
    cmp::Reverse,
    collections::BinaryHeap,
    fs::{self, File},
    io::{BufRead, BufReader, BufWriter, Read, Write},
    path::{Path, PathBuf},
    str::FromStr,
};

use anyhow::{Context, Result, bail};
use rayon::prelude::*;
use tempfile::TempDir;

use crate::{ngram, segment};

pub type Record = (ngram::GramHash, u32);
const MIB: usize = 1024 * 1024;
pub const CHUNK_BYTES: usize = 32 * 1024;
// Every longer gram links a bigram to its nearest >= neighbor on one side.
// At most two such grams per bigram, plus trigrams: < 3 hashes per byte.
// Reserve space for u64 dedup, compact output, queued chunks, and I/O.
const WORKER_BYTES: usize = 8 * MIB;
const IO_BYTES: usize = 64 * 1024;
const MERGE_FAN_IN: usize = 32;
const FIXED_BYTES: usize = 4 * MIB;

#[derive(Clone, Copy, Debug)]
pub struct MemoryBudget(usize);

impl FromStr for MemoryBudget {
    type Err = String;

    fn from_str(value: &str) -> std::result::Result<Self, Self::Err> {
        let mib: usize = value
            .parse()
            .map_err(|_| "expected an integer MiB budget")?;
        if mib < 16 {
            return Err("build memory budget must be at least 16 MiB".into());
        }
        mib.checked_mul(MIB)
            .filter(|&bytes| bytes <= isize::MAX as usize)
            .map(Self)
            .ok_or_else(|| "build memory budget is too large".into())
    }
}

impl MemoryBudget {
    pub fn workers(self, files: usize) -> usize {
        rayon::current_num_threads()
            .min(files.max(1))
            .min((self.0 / 4 / WORKER_BYTES).max(1))
    }

    pub fn record_bytes(self, workers: usize) -> usize {
        self.0 - workers * WORKER_BYTES - FIXED_BYTES
    }
}

struct Run {
    path: PathBuf,
    ngrams: u64,
    bytes: u64,
}

pub struct PostingsBuilder {
    index_dir: PathBuf,
    records: Vec<Record>,
    limit: usize,
    temporary: Option<TempDir>,
    runs: Vec<Run>,
    next_run: usize,
    spilled_runs: usize,
    temporary_bytes: u64,
    live_temporary_bytes: u64,
    peak_temporary_bytes: u64,
}

impl PostingsBuilder {
    pub fn new(index_dir: &Path, record_bytes: usize) -> Self {
        Self {
            index_dir: index_dir.to_owned(),
            records: Vec::new(),
            limit: (record_bytes / size_of::<Record>()).max(1),
            temporary: None,
            runs: Vec::new(),
            next_run: 0,
            spilled_runs: 0,
            temporary_bytes: 0,
            live_temporary_bytes: 0,
            peak_temporary_bytes: 0,
        }
    }

    pub fn extend(&mut self, id: u32, hashes: &[ngram::GramHash]) -> Result<()> {
        if self.records.capacity() == 0 && !hashes.is_empty() {
            // Allocate once: geometric Vec growth can temporarily retain both
            // the old and new allocation, exceeding the record budget.
            self.records = Vec::with_capacity(self.limit);
        }
        let mut hashes = hashes;
        while !hashes.is_empty() {
            if self.records.len() == self.limit {
                self.spill()?;
            }
            let count = hashes.len().min(self.limit - self.records.len());
            self.records
                .extend(hashes[..count].iter().map(|&hash| (hash, id)));
            hashes = &hashes[count..];
        }
        Ok(())
    }

    fn run_path(&mut self) -> Result<PathBuf> {
        if self.temporary.is_none() {
            self.temporary = Some(
                tempfile::Builder::new()
                    .prefix(".build-")
                    .tempdir_in(&self.index_dir)
                    .context("cannot create temporary index sort directory")?,
            );
        }
        let path = self
            .temporary
            .as_ref()
            .unwrap()
            .path()
            .join(format!("{}.run", self.next_run));
        self.next_run += 1;
        Ok(path)
    }

    fn spill(&mut self) -> Result<()> {
        self.records.par_sort_unstable();
        self.records.dedup();
        let path = self.run_path()?;
        let mut writer = RunWriter::new(&path)?;
        for &record in &self.records {
            writer.push(record)?;
        }
        let (run, bytes) = writer.finish(path)?;
        self.record_temporary_write(bytes);
        self.spilled_runs += 1;
        self.runs.push(run);
        self.records.clear();
        Ok(())
    }

    fn record_temporary_write(&mut self, bytes: u64) {
        self.temporary_bytes += bytes;
        self.live_temporary_bytes += bytes;
        self.peak_temporary_bytes = self.peak_temporary_bytes.max(self.live_temporary_bytes);
    }

    pub fn write(mut self, id: u64) -> Result<segment::SegmentMeta> {
        if self.runs.is_empty() {
            self.records.par_sort_unstable();
            self.records.dedup();
            let ngrams = self.records.chunk_by(|a, b| a.0 == b.0).count() as u64;
            return segment::write_sorted(
                &self.index_dir,
                id,
                ngrams,
                self.records.iter().copied().map(Ok),
            );
        }
        if !self.records.is_empty() {
            self.spill()?;
        }
        // No extraction workers remain. Release the large sort buffer before
        // opening bounded merge readers or encoding the final segment.
        self.records = Vec::new();
        while self.runs.len() > 1 {
            let mut remaining = std::mem::take(&mut self.runs).into_iter();
            loop {
                let inputs: Vec<_> = remaining.by_ref().take(MERGE_FAN_IN).collect();
                if inputs.is_empty() {
                    break;
                }
                if inputs.len() == 1 {
                    self.runs.extend(inputs);
                    continue;
                }
                let output = self.run_path()?;
                let (run, bytes) = merge_runs(&inputs, output)?;
                self.record_temporary_write(bytes);
                for input in inputs {
                    fs::remove_file(input.path)?;
                    self.live_temporary_bytes -= input.bytes;
                }
                self.runs.push(run);
            }
        }
        let run = self.runs.pop().unwrap();
        let reader = RunReader::new(&run.path)?;
        let meta = segment::write_sorted(&self.index_dir, id, run.ngrams, reader)?;
        eprintln!(
            "coderg: spilled {} build runs ({} temporary bytes written, {} peak temporary bytes)",
            self.spilled_runs, self.temporary_bytes, self.peak_temporary_bytes,
        );
        Ok(meta)
    }
}

struct RunWriter {
    file: BufWriter<File>,
    previous: Option<Record>,
    ngrams: u64,
    bytes: u64,
}

impl RunWriter {
    fn new(path: &Path) -> Result<Self> {
        Ok(Self {
            file: BufWriter::with_capacity(IO_BYTES, File::create(path)?),
            previous: None,
            ngrams: 0,
            bytes: 0,
        })
    }

    fn push(&mut self, record: Record) -> Result<()> {
        if self.previous == Some(record) {
            return Ok(());
        }
        if self.previous.is_none_or(|previous| previous.0 != record.0) {
            self.ngrams += 1;
        }
        let mut bytes = [0; 8];
        bytes[..4].copy_from_slice(&record.0.to_le_bytes());
        bytes[4..].copy_from_slice(&record.1.to_le_bytes());
        self.file.write_all(&bytes)?;
        self.bytes += 8;
        self.previous = Some(record);
        Ok(())
    }

    fn finish(mut self, path: PathBuf) -> Result<(Run, u64)> {
        self.file.flush()?;
        Ok((
            Run {
                path,
                ngrams: self.ngrams,
                bytes: self.bytes,
            },
            self.bytes,
        ))
    }
}

struct RunReader(BufReader<File>);

impl RunReader {
    fn new(path: &Path) -> Result<Self> {
        let file = File::open(path)?;
        if file.metadata()?.len() % 8 != 0 {
            bail!("truncated temporary posting run: {}", path.display());
        }
        Ok(Self(BufReader::with_capacity(IO_BYTES, file)))
    }
}

impl Iterator for RunReader {
    type Item = Result<Record>;

    fn next(&mut self) -> Option<Self::Item> {
        loop {
            match self.0.fill_buf() {
                Ok([]) => return None,
                Ok(bytes) if bytes.len() >= 8 => {
                    let record = (
                        u32::from_le_bytes(bytes[..4].try_into().unwrap()),
                        u32::from_le_bytes(bytes[4..8].try_into().unwrap()),
                    );
                    self.0.consume(8);
                    return Some(Ok(record));
                }
                Ok(_) => break,
                Err(error) if error.kind() == std::io::ErrorKind::Interrupted => continue,
                Err(error) => return Some(Err(error.into())),
            }
        }
        // A short buffered read can split a record. read_exact rejects an
        // incomplete final record instead of treating it as a clean EOF.
        let mut bytes = [0; 8];
        Some(
            self.0
                .read_exact(&mut bytes)
                .map(|()| {
                    (
                        u32::from_le_bytes(bytes[..4].try_into().unwrap()),
                        u32::from_le_bytes(bytes[4..].try_into().unwrap()),
                    )
                })
                .map_err(Into::into),
        )
    }
}

fn merge_runs(inputs: &[Run], output: PathBuf) -> Result<(Run, u64)> {
    let mut readers: Vec<_> = inputs
        .iter()
        .map(|run| RunReader::new(&run.path))
        .collect::<Result<_>>()?;
    let mut heap = BinaryHeap::new();
    for (index, reader) in readers.iter_mut().enumerate() {
        if let Some((hash, id)) = reader.next().transpose()? {
            heap.push(Reverse((hash, id, index)));
        }
    }
    let mut writer = RunWriter::new(&output)?;
    while let Some(Reverse((hash, id, index))) = heap.pop() {
        writer.push((hash, id))?;
        if let Some((hash, id)) = readers[index].next().transpose()? {
            heap.push(Reverse((hash, id, index)));
        }
    }
    writer.finish(output)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn budget_reserves_space_for_producers_and_io() {
        for mib in [16, 32, 64, 256, 1024] {
            let budget: MemoryBudget = mib.to_string().parse().unwrap();
            let workers = budget.workers(100_000);
            assert!(workers >= 1);
            assert!(budget.record_bytes(workers) >= 4 * MIB);
            assert_eq!(
                budget.record_bytes(workers) + workers * WORKER_BYTES + FIXED_BYTES,
                mib * MIB
            );
        }
        for invalid in ["0", "15", "-1", "1.5", "18446744073709551615"] {
            assert!(invalid.parse::<MemoryBudget>().is_err());
        }
    }

    #[test]
    fn many_merge_runs_match_in_memory_bytes_and_clean_up() {
        let disk = tempfile::tempdir().unwrap();
        let memory = tempfile::tempdir().unwrap();
        // More than 32 runs exercises multiple merge passes, repeated keys,
        // duplicate IDs across runs, and a partial final lookup block.
        let mut external = PostingsBuilder::new(disk.path(), 3 * size_of::<Record>());
        let mut in_memory = PostingsBuilder::new(memory.path(), MIB);
        for id in (0..5).rev().chain([u32::MAX, 0]) {
            let hashes: Vec<_> = (0..259).rev().chain([u32::MAX, 0, 128]).collect();
            external.extend(id, &hashes).unwrap();
            in_memory.extend(id, &hashes).unwrap();
            assert!(external.records.capacity() <= external.limit);
        }
        assert!(external.runs.len() > MERGE_FAN_IN);
        let actual = external.write(1).unwrap();
        let expected = in_memory.write(1).unwrap();
        assert_eq!(actual.ngrams, 260);
        for (actual_path, expected_path) in [
            (actual.lookup, expected.lookup),
            (actual.postings, expected.postings),
        ] {
            assert_eq!(
                fs::read(disk.path().join(actual_path)).unwrap(),
                fs::read(memory.path().join(expected_path)).unwrap()
            );
        }
        assert_eq!(fs::read_dir(disk.path()).unwrap().count(), 1);
        assert_eq!(
            fs::read_dir(disk.path().join("segments")).unwrap().count(),
            2
        );
    }

    #[test]
    fn failed_segment_write_removes_temporary_runs() {
        let directory = tempfile::tempdir().unwrap();
        let mut builder = PostingsBuilder::new(directory.path(), 8);
        builder.extend(0, &[1, 2, 3]).unwrap();
        let temporary = builder.temporary.as_ref().unwrap().path().to_owned();
        assert!(temporary.is_dir());
        fs::write(
            directory.path().join("segments"),
            "cannot create a directory here",
        )
        .unwrap();
        assert!(builder.write(1).is_err());
        assert!(!temporary.exists());
    }

    #[test]
    fn truncated_run_is_rejected() {
        let directory = tempfile::tempdir().unwrap();
        let path = directory.path().join("broken.run");
        fs::write(&path, [0; 7]).unwrap();
        assert!(RunReader::new(&path).is_err());
    }
}
