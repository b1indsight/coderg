#![allow(dead_code, unused_mut)]
mod build;
mod compaction;
mod git_state;
#[cfg(not(feature = "mask-experiment"))]
mod index;
#[cfg(feature = "mask-experiment")]
#[path = "index_mask.rs"]
mod index;
mod manifest;
mod ngram;
mod segment;
mod update_masks;

use anyhow::Result;
use std::{path::PathBuf, time::Instant};
fn main() -> Result<()> {
    let args: Vec<_> = std::env::args().collect();
    let root = PathBuf::from(&args[2]).canonicalize()?;
    let directory = PathBuf::from(&args[3]);
    let mode: usize = args[4].parse()?;
    update_masks::MODE.store(mode, std::sync::atomic::Ordering::Relaxed);
    let budget = "256".parse::<build::MemoryBudget>().map_err(anyhow::Error::msg)?;
    let start = Instant::now();
    let mut merge = serde_json::Value::Null;
    let (load_ms, refresh_ms, outcome) = if args[1] == "build" {
        index::build(&root, Some(&directory), budget)?;
        (0., start.elapsed().as_secs_f64()*1000., "build".to_string())
    } else {
        let mut snapshot = index::load(&root, Some(&directory))?;
        let load_ms = start.elapsed().as_secs_f64()*1000.;
        let refresh_start = Instant::now();
        let outcome = match index::refresh(&mut snapshot, Some(&directory), budget)? {
            index::RefreshOutcome::Unchanged => "unchanged".to_string(),
            index::RefreshOutcome::CommitAdvanced => "commit".to_string(),
            index::RefreshOutcome::Rebuilt => "rebuild".to_string(),
            index::RefreshOutcome::Incremental { changed, compaction } => {
                merge = serde_json::to_value(compaction)?;
                format!("incremental:{changed}")
            },
        };
        (load_ms, refresh_start.elapsed().as_secs_f64()*1000., outcome)
    };
    let total_ms = start.elapsed().as_secs_f64()*1000.;
    println!("{}", serde_json::json!({"load_ms":load_ms,"refresh_ms":refresh_ms,"total_ms":total_ms,"outcome":outcome,"compaction":merge,"mask":update_masks::metrics()}));
    Ok(())
}
