//! Experimental per-document sidecar. Not the production index format.
use anyhow::Result;
use std::{io::Write, path::Path, sync::atomic::{AtomicU64, AtomicUsize, Ordering}, time::Instant};

pub static MODE: AtomicUsize = AtomicUsize::new(0);
static COMPUTE_NS: AtomicU64 = AtomicU64::new(0);
static WRITE_NS: AtomicU64 = AtomicU64::new(0);
static WRITTEN_BYTES: AtomicU64 = AtomicU64::new(0);
static FILES: AtomicU64 = AtomicU64::new(0);

pub fn metrics() -> serde_json::Value {
    serde_json::json!({"compute_worker_ms": COMPUTE_NS.load(Ordering::Relaxed) as f64 / 1e6,
        "write_worker_ms": WRITE_NS.load(Ordering::Relaxed) as f64 / 1e6,
        "written_bytes": WRITTEN_BYTES.load(Ordering::Relaxed), "files": FILES.load(Ordering::Relaxed)})
}

pub struct Accumulator<'a> {
    mode: usize,
    target: Option<(&'a Path, u32)>,
    masks: crate::ngram::GramHashMap<u8>,
}
impl<'a> Accumulator<'a> {
    pub fn new(target: Option<(&'a Path, u32)>) -> Self {
        Self { mode: MODE.load(Ordering::Relaxed), target, masks: Default::default() }
    }
    pub fn observe(&mut self, bytes: &[u8]) {
        if self.mode == 0 { return; }
        let start = Instant::now();
        for w in bytes.windows(4) {
            let key = u32::from_le_bytes([w[0], w[1], w[2], 0]);
            *self.masks.entry(key).or_default() |= 1 << (crate::ngram::hash(&w[3..4]) & 7);
        }
        if bytes.len() >= 3 {
            let last = &bytes[bytes.len()-3..];
            self.masks.entry(u32::from_le_bytes([last[0], last[1], last[2], 0])).or_default();
        }
        COMPUTE_NS.fetch_add(start.elapsed().as_nanos() as u64, Ordering::Relaxed);
    }
    pub fn finish(self) -> Result<()> {
        if self.mode == 0 { return Ok(()); }
        let start = Instant::now();
        let mut records: Vec<_> = self.masks.into_iter().collect();
        records.sort_unstable_by_key(|&(key, _)| key);
        let mut bytes = Vec::with_capacity(records.len() * 4);
        for (key, mask) in records { bytes.extend_from_slice(&(key | ((mask as u32) << 24)).to_le_bytes()); }
        COMPUTE_NS.fetch_add(start.elapsed().as_nanos() as u64, Ordering::Relaxed);
        std::hint::black_box(&bytes);
        FILES.fetch_add(1, Ordering::Relaxed);
        if self.mode >= 2 {
            if let Some((index, id)) = self.target {
                let start = Instant::now();
                let directory = index.join("nextmask-docs");
                std::fs::create_dir_all(&directory)?;
                let mut temp = tempfile::NamedTempFile::new_in(&directory)?;
                temp.write_all(&bytes)?;
                if self.mode == 3 { temp.as_file().sync_all()?; }
                temp.persist(directory.join(format!("{id:010}.mask")))?;
                if self.mode == 3 { std::fs::File::open(&directory)?.sync_all()?; }
                WRITE_NS.fetch_add(start.elapsed().as_nanos() as u64, Ordering::Relaxed);
                WRITTEN_BYTES.fetch_add(bytes.len() as u64, Ordering::Relaxed);
            }
        }
        Ok(())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn sidecar_matches_whole_file_and_replaces_bits() {
        MODE.store(2, Ordering::Relaxed);
        let dir = tempfile::tempdir().unwrap();
        let mut a = Accumulator::new(Some((dir.path(), 7)));
        a.observe(b"rocmroce");
        a.finish().unwrap();
        let path = dir.path().join("nextmask-docs/0000000007.mask");
        let before = std::fs::read(&path).unwrap();
        let mut a = Accumulator::new(Some((dir.path(), 7)));
        a.observe(b"rocZ");
        a.finish().unwrap();
        let after = std::fs::read(&path).unwrap();
        assert_ne!(before, after);
        assert_eq!(&after[..3], b"ocZ");
        assert_eq!(after[3], 0); // EOF trigram has no successor.
        let row = after.chunks_exact(4).find(|r| &r[..3] == b"roc").unwrap();
        assert_eq!(row[3], 1 << (crate::ngram::hash(b"Z") & 7));
        let mut whole = Accumulator::new(None);
        whole.observe(b"abcdefghijklmnopqrstuvwx");
        let mut chunked = Accumulator::new(None);
        chunked.observe(b"abcdefghijklmnop");
        chunked.observe(b"nopqrstuvwx");
        assert_eq!(whole.masks, chunked.masks);
    }
}
