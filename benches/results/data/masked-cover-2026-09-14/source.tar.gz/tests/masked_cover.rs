#![allow(dead_code)]
#[path = "../src/build.rs"]
mod build;
#[path = "../src/manifest.rs"]
mod manifest;
#[path = "../benches/support/masked_cover.rs"]
mod masked_cover;
#[path = "../benches/support/gram_source.rs"]
mod ngram;
#[path = "../benches/support/literal_source.rs"]
mod query;
#[path = "../src/segment.rs"]
mod segment;

use masked_cover::{Mode, Term};
use std::collections::BTreeSet;

#[test]
fn masked_cover_replaces_two_trigrams_with_one_four_byte_predicate() {
    let old = masked_cover::cover(b"test", Mode::Baseline);
    let new = masked_cover::cover(b"test", Mode::MaskedCover);
    assert_eq!(old.len(), 2);
    assert_eq!(new.len(), 1);
    assert_eq!(new[0].next, Some(*b"test"));
}

#[test]
fn masked_cover_spans_all_trigram_positions_and_prefers_exact_fourgrams() {
    let mut seed = 29u64;
    let mut exact_fourgrams = 0;
    for len in 0..100 {
        for _ in 0..20 {
            let bytes: Vec<_> = (0..len)
                .map(|_| {
                    seed = seed.wrapping_mul(6364136223846793005).wrapping_add(1);
                    b'a' + ((seed >> 32) % 26) as u8
                })
                .collect();
            let spans = masked_cover::covering_spans(&bytes);
            for position in 0..bytes.len().saturating_sub(2) {
                assert!(
                    spans
                        .iter()
                        .any(|s| s.start <= position && s.start + s.cover_len >= position + 3)
                );
            }
            for s in &spans {
                assert!(s.start + s.cover_len <= bytes.len());
                assert_eq!(
                    s.cover_len,
                    if s.term.next.is_some() { 4 } else { s.key_len }
                );
                if s.term.next.is_some() {
                    assert_eq!(s.key_len, 3);
                }
            }
            if len == 4 {
                ngram::visit(&bytes, |_, gram, _| {
                    if gram.len() == 4 {
                        exact_fourgrams += 1;
                        let cover = masked_cover::cover(&bytes, Mode::MaskedCover);
                        assert_eq!(cover.len(), 1);
                        assert!(cover[0].next.is_none());
                    }
                });
            }
        }
    }
    assert!(exact_fourgrams > 0);
}

#[test]
fn masked_cover_budget_counts_raw_keys_and_keeps_mask_variants_separate() {
    let d = Term {
        hash: 7,
        next: Some(*b"abcd"),
    };
    let e = Term {
        hash: 7,
        next: Some(*b"abce"),
    };
    let (ids, stats) = masked_cover::execute(
        &vec![vec![vec![d], vec![e]]],
        |_| Ok(vec![1, 2]),
        |t, id| if t == d { id == 1 } else { id == 2 },
        1,
    )
    .unwrap();
    assert_eq!(ids.unwrap(), BTreeSet::from([1, 2]));
    assert_eq!(stats.posting_reads, 1);
    assert_eq!(stats.masked_predicates, 2);
    let (ids, _) = masked_cover::execute(
        &vec![vec![vec![d, e]]],
        |_| Ok(vec![1, 2]),
        |t, id| if t == d { id == 1 } else { id == 2 },
        1,
    )
    .unwrap();
    assert!(ids.unwrap().is_empty());
}

#[test]
fn masked_cover_never_applies_partial_or_when_budget_is_exhausted() {
    let a = Term {
        hash: 1,
        next: Some(*b"abcd"),
    };
    let b = Term {
        hash: 2,
        next: Some(*b"wxyz"),
    };
    let (ids, stats) = masked_cover::execute(
        &vec![vec![vec![a], vec![b]]],
        |_| panic!("partial group should not load anything"),
        |_, _| true,
        1,
    )
    .unwrap();
    assert!(ids.is_none());
    assert_eq!(stats.posting_reads, 0);
}

#[test]
fn masked_cover_handles_eof_overlap_and_hash_bit_collisions() {
    assert_eq!(masked_cover::document_mask(b"aaa", b"aaa"), 0);
    let mask = masked_cover::document_mask(b"aaaab", b"aaa");
    for b in [b'a', b'b'] {
        assert_ne!(mask & masked_cover::next_bit(b), 0);
    }
    let bytes: Vec<_> = (0..=255).flat_map(|b| [b'a', b'b', b'c', b]).collect();
    assert_eq!(masked_cover::document_mask(&bytes, b"abc"), 255);
    for byte in 0..=255 {
        let doc = [b'a', b'b', b'c', byte];
        assert_ne!(
            masked_cover::document_mask(&doc, b"abc") & masked_cover::next_bit(byte),
            0
        );
    }
}

#[test]
fn masked_cover_preserves_regex_matches_with_alternation_case_and_budgets() {
    let docs: Vec<Vec<u8>> = [
        "test",
        "rates best",
        "testing",
        "abcd",
        "abc___d",
        "xyz",
        "abc",
        "ABCD",
        "abcd wxyz",
        "éabcδ",
        "aaaab",
        "abce",
        "",
        "prefix1suffix",
        "prefix123suffix",
        "return None",
        "SamplingParams",
        "samplingparams",
        "foo bar",
        "foobar",
        "abcde",
    ]
    .iter()
    .map(|s| s.as_bytes().to_vec())
    .collect();
    let hashes: Vec<_> = docs.iter().map(|d| ngram::hashes_for_document(d)).collect();
    for pattern in [
        r"test",
        r"\btest\b",
        "abcd|xyz",
        "abc.*d",
        "abcd?",
        "(?:abcd)?",
        "[ab]cde",
        "(?i)abcd",
        "éabcδ",
        "aaaab",
        "abcd|abce",
        "prefix[0-9A-Z]+suffix",
        "(?i)SamplingParams",
        "foo.*bar",
        "abcd.*wxyz",
    ] {
        let literals = query::literals(pattern, false).unwrap();
        let regex = regex::bytes::Regex::new(pattern).unwrap();
        for mode in [Mode::Baseline, Mode::OldCoverMask, Mode::MaskedCover] {
            let plan = masked_cover::plan(&literals, mode);
            for budget in [0, 1, 2, 8, 128] {
                let (ids, stats) = masked_cover::execute(
                    &plan,
                    |h| {
                        Ok(hashes
                            .iter()
                            .enumerate()
                            .filter(|(_, s)| s.contains(&h))
                            .map(|(i, _)| i as u32)
                            .collect())
                    },
                    |t, id| {
                        let q = t.next.unwrap();
                        masked_cover::document_mask(&docs[id as usize], q[..3].try_into().unwrap())
                            & masked_cover::next_bit(q[3])
                            != 0
                    },
                    budget,
                )
                .unwrap();
                assert!(stats.posting_reads <= budget);
                for (id, doc) in docs.iter().enumerate() {
                    if regex.is_match(doc) {
                        assert!(
                            ids.as_ref().is_none_or(|ids| ids.contains(&(id as u32))),
                            "{pattern} {mode:?} {budget} {doc:?}"
                        );
                    }
                }
            }
        }
    }
}

#[test]
fn masked_cover_reuses_raw_key_across_different_trigram_hash_collisions() {
    let a = Term {
        hash: 9,
        next: Some(*b"abcd"),
    };
    let b = Term {
        hash: 9,
        next: Some(*b"wxyz"),
    };
    let docs = [b"abcd".as_slice(), b"wxyz", b"abcd wxyz"];
    let (ids, stats) = masked_cover::execute(
        &vec![vec![vec![a, b]]],
        |_| Ok(vec![0, 1, 2]),
        |t, id| {
            let q = t.next.unwrap();
            masked_cover::document_mask(docs[id as usize], q[..3].try_into().unwrap())
                & masked_cover::next_bit(q[3])
                != 0
        },
        1,
    )
    .unwrap();
    assert_eq!(ids.unwrap(), BTreeSet::from([2]));
    assert_eq!(stats.posting_reads, 1);
}
