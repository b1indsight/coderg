//! Experimental covering and execution with masks attached to branch predicates.
use crate::{ngram, query};
use anyhow::Result;
use serde::Serialize;
use std::collections::{BTreeSet, HashMap, HashSet};
use std::time::Instant;

#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd, Hash, Serialize)]
pub struct Term {
    pub hash: u32,
    pub next: Option<[u8; 4]>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize)]
pub enum Mode {
    Baseline,
    OldCoverMask,
    MaskedCover,
}

#[derive(Clone, Copy, Debug, Serialize)]
pub struct Span {
    pub start: usize,
    pub key_len: usize,
    pub cover_len: usize,
    pub term: Term,
}

impl Span {
    fn new(bytes: &[u8], start: usize, len: usize, hash: u32, mask: bool) -> Self {
        let next = (mask && len == 3 && start + 3 < bytes.len())
            .then(|| bytes[start..start + 4].try_into().unwrap());
        Self {
            start,
            key_len: len,
            cover_len: if next.is_some() { 4 } else { len },
            term: Term { hash, next },
        }
    }
    fn end(self) -> usize {
        self.start + self.cover_len
    }
}

pub fn covering_spans(bytes: &[u8]) -> Vec<Span> {
    let mut longest: Vec<Span> = Vec::new();
    ngram::visit(bytes, |start, gram, hash| {
        let candidate = Span::new(bytes, start, gram.len(), hash, true);
        if start == longest.len() {
            longest.push(candidate);
        } else if (candidate.cover_len, candidate.key_len)
            > (longest[start].cover_len, longest[start].key_len)
        {
            // A real four-byte sparse gram wins a tie with a masked trigram.
            longest[start] = candidate;
        }
    });
    let Some(&anchor) = longest
        .iter()
        .max_by_key(|g| (g.cover_len, g.key_len, g.start))
    else {
        return Vec::new();
    };
    let mut selected = vec![anchor];
    let mut next_start = 0;
    let mut covered = 2;
    while covered < bytes.len() {
        let mut best = longest[next_start];
        // Effective four-byte spans cover two trigram positions. Retain the
        // existing two-byte overlap rule at joins.
        while next_start < longest.len() && next_start <= covered - 2 {
            let g = longest[next_start];
            if (g.end(), g.key_len, g.start) >= (best.end(), best.key_len, best.start) {
                best = g;
            }
            next_start += 1;
        }
        covered = best.end();
        selected.push(best);
    }
    selected
}

pub fn cover(bytes: &[u8], mode: Mode) -> Vec<Term> {
    let mut spans = if mode == Mode::MaskedCover {
        covering_spans(bytes)
    } else {
        ngram::old_spans(bytes)
            .into_iter()
            .map(|(start, len, hash)| {
                Span::new(bytes, start, len, hash, mode == Mode::OldCoverMask)
            })
            .collect()
    };
    if mode == Mode::MaskedCover {
        spans.sort_unstable_by_key(|g| std::cmp::Reverse((g.cover_len, g.key_len, g.start)));
    }
    let mut seen = HashSet::new();
    spans
        .into_iter()
        .map(|g| g.term)
        .filter(|t| seen.insert(*t))
        .take(query::MAX_INDEX_LOOKUPS)
        .collect()
}

pub type Group = Vec<Vec<Term>>;
pub type Plan = Vec<Group>;

pub fn plan(literals: &[Vec<Vec<u8>>], mode: Mode) -> Plan {
    let mut plan = Vec::new();
    for group in literals {
        let mut branches: Group = Vec::new();
        for literal in group {
            let terms = cover(literal, mode);
            if branches.iter().any(|b| b.iter().all(|t| terms.contains(t))) {
                continue;
            }
            branches.retain(|b| !terms.iter().all(|t| b.contains(t)));
            branches.push(terms);
        }
        if !plan.contains(&branches) {
            plan.push(branches);
        }
    }
    plan
}

pub fn next_bit(byte: u8) -> u8 {
    1 << (ngram::hash(&[byte]) & 7)
}

pub fn document_mask(bytes: &[u8], key: &[u8; 3]) -> u8 {
    let finder = memchr::memmem::Finder::new(key);
    let mut start = 0;
    let mut mask = 0;
    while let Some(offset) = finder.find(&bytes[start..]) {
        let position = start + offset;
        if let Some(&next) = bytes.get(position + 3) {
            mask |= next_bit(next);
        }
        start = position + 1;
        if mask == 255 {
            break;
        }
    }
    mask
}

#[derive(Default, Debug, Serialize)]
pub struct Stats {
    pub posting_reads: usize,
    pub decoded_ids: usize,
    pub masked_predicates: usize,
    pub mask_checks: usize,
    pub mask_rejected_ids: usize,
    pub posting_load_ms: f64,
    pub mask_filter_ms: f64,
    pub loaded_keys: Vec<u32>,
}

struct Cache<L, M> {
    load: L,
    mask: M,
    raw: HashMap<u32, Vec<u32>>,
    filtered: HashMap<Term, Vec<u32>>,
    stats: Stats,
}

impl<L, M> Cache<L, M>
where
    L: FnMut(u32) -> Result<Vec<u32>>,
    M: FnMut(Term, u32) -> bool,
{
    fn prepare(&mut self, term: Term) -> Result<()> {
        if !self.raw.contains_key(&term.hash) {
            let start = Instant::now();
            let ids = (self.load)(term.hash)?;
            self.stats.posting_load_ms += start.elapsed().as_secs_f64() * 1000.0;
            self.stats.posting_reads += 1;
            self.stats.decoded_ids += ids.len();
            self.stats.loaded_keys.push(term.hash);
            self.raw.insert(term.hash, ids);
        }
        if term.next.is_some() && !self.filtered.contains_key(&term) {
            let start = Instant::now();
            let raw = &self.raw[&term.hash];
            let ids: Vec<_> = raw
                .iter()
                .copied()
                .filter(|&id| (self.mask)(term, id))
                .collect();
            self.stats.mask_filter_ms += start.elapsed().as_secs_f64() * 1000.0;
            self.stats.masked_predicates += 1;
            self.stats.mask_checks += raw.len();
            self.stats.mask_rejected_ids += raw.len() - ids.len();
            self.filtered.insert(term, ids);
        }
        Ok(())
    }
    fn get(&self, term: Term) -> &[u32] {
        if term.next.is_some() {
            &self.filtered[&term]
        } else {
            &self.raw[&term.hash]
        }
    }
}

// Same anchor/branch/refinement structure as production intersect_postings.
// The budget and raw cache are keyed by physical hash, while filtered lists
// are keyed by the full predicate. Different fourth bytes must not alias.
pub fn execute(
    plan: &Plan,
    load: impl FnMut(u32) -> Result<Vec<u32>>,
    mask: impl FnMut(Term, u32) -> bool,
    budget: usize,
) -> Result<(Option<BTreeSet<u32>>, Stats)> {
    let mut c = Cache {
        load,
        mask,
        raw: HashMap::new(),
        filtered: HashMap::new(),
        stats: Stats::default(),
    };
    let mut candidates: Option<BTreeSet<u32>> = None;
    let mut seeded = Vec::new();
    for alternatives in plan {
        if alternatives.is_empty() || alternatives.iter().any(Vec::is_empty) {
            continue;
        }
        let new: BTreeSet<_> = alternatives
            .iter()
            .map(|b| b[0].hash)
            .filter(|k| !c.raw.contains_key(k))
            .collect();
        if c.raw.len() + new.len() > budget {
            continue;
        }
        for &hash in &new {
            c.prepare(Term { hash, next: None })?;
        }
        for b in alternatives {
            c.prepare(b[0])?;
        }
        let union: BTreeSet<_> = alternatives
            .iter()
            .flat_map(|b| c.get(b[0]).iter().copied())
            .collect();
        if let Some(current) = &mut candidates {
            current.retain(|id| union.contains(id));
        } else {
            candidates = Some(union);
        }
        if candidates.as_ref().is_some_and(BTreeSet::is_empty) {
            return Ok((candidates, c.stats));
        }
        seeded.push(alternatives);
    }
    let Some(mut candidates) = candidates else {
        return Ok((None, c.stats));
    };
    for alternatives in seeded {
        if alternatives.iter().all(|b| b.len() == 1) {
            continue;
        }
        let mut branches: Vec<_> = alternatives.iter().collect();
        branches.sort_by_key(|b| {
            (
                b.iter().filter(|t| !c.raw.contains_key(&t.hash)).count(),
                c.get(b[0]).len(),
            )
        });
        let mut accepted = BTreeSet::new();
        for branch in branches {
            let mut remaining: Vec<_> = c
                .get(branch[0])
                .iter()
                .copied()
                .filter(|id| candidates.contains(id) && !accepted.contains(id))
                .collect();
            if remaining.is_empty() {
                continue;
            }
            let (mut cached, unread): (Vec<_>, Vec<_>) = branch[1..]
                .iter()
                .copied()
                .partition(|t| c.raw.contains_key(&t.hash));
            cached.sort_by_key(|t| c.raw[&t.hash].len());
            for term in cached.into_iter().chain(unread) {
                if !c.raw.contains_key(&term.hash) && c.raw.len() == budget {
                    continue;
                }
                c.prepare(term)?;
                remaining.retain(|id| c.get(term).binary_search(id).is_ok());
                if remaining.is_empty() {
                    break;
                }
            }
            accepted.extend(remaining);
            if accepted.len() == candidates.len() {
                break;
            }
        }
        candidates = accepted;
        if candidates.is_empty() {
            break;
        }
    }
    Ok((Some(candidates), c.stats))
}
