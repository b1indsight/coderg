include!("../../src/query.rs");

pub fn literals(pattern: &str, ignore_case: bool) -> Result<Vec<Vec<Vec<u8>>>> {
    let hir = ParserBuilder::new()
        .case_insensitive(ignore_case)
        .multi_line(true)
        .utf8(false)
        .build()
        .parse(pattern)?;
    Ok(required_literal_groups(&hir))
}
