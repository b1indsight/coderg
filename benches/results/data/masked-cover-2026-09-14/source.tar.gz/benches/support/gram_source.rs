// Access the production extractor without changing the production API.
include!("../../src/ngram.rs");

pub fn visit(bytes: &[u8], mut emit: impl FnMut(usize, &[u8], GramHash)) {
    for_each_sparse_gram(bytes, |start, gram, hash| {
        emit(start, gram, compact_hash(hash))
    });
}

pub fn old_spans(bytes: &[u8]) -> Vec<(usize, usize, GramHash)> {
    let mut grams = covering_grams(bytes);
    grams.sort_unstable_by_key(|g| std::cmp::Reverse((g.len, g.start)));
    let mut seen = GramHashSet::default();
    grams
        .into_iter()
        .filter(|g| seen.insert(g.hash))
        .take(crate::query::MAX_INDEX_LOOKUPS)
        .map(|g| (g.start, g.len, g.hash))
        .collect()
}
