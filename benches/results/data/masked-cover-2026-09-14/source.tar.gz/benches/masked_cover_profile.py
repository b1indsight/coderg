#!/usr/bin/env python3
"""Compare baseline, masks on old covering, and four-byte masked covering.

Reuses the immutable corpora and complete verified match maps from the first
experiment. Every query rescans the union of all three candidate sets and checks
the complete result map; changed covering can admit files absent from baseline.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import random
import statistics
import subprocess

MODES = ('Baseline', 'OldCoverMask', 'MaskedCover')
SCAN_QUERIES = {
    'vllm': {'literal_test', 'word_test', 'icase_sampling', 'return_none', 'def_forward', 'icase_literal'},
    'chromium': {'literal_test', 'word_test', 'icase_weak_ptr_factory', 'class_decl', 'max_file_size'},
}

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def summarize(report):
    result = {}
    for mode in MODES:
        samples = [s for s in report['query_samples'] if s['mode'] == mode]
        stats = dict(next(s for s in report['summaries'] if s['mode'] == mode))
        stats['query_ms'] = statistics.median(s['query_ms'] for s in samples)
        for key in samples[0]['stats']:
            if key != 'loaded_keys':
                stats[key] = statistics.median(s['stats'][key] for s in samples)
        scans = [s for s in report['scan_samples'] if s['mode'] == mode]
        stats['scan'] = {k: statistics.median(s[k] for s in scans) for k in scans[0] if k != 'mode'} if scans else None
        result[mode] = stats
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--suite', choices=['vllm', 'chromium'], required=True)
    parser.add_argument('--previous', type=Path, default=Path('.cache/2026-09-10/nextmask-profile'))
    parser.add_argument('--work', type=Path, default=Path('.cache/2026-09-10/masked-cover-profile'))
    parser.add_argument('--profiler', type=Path, required=True)
    parser.add_argument('--iterations', type=int, default=9)
    parser.add_argument('--scan-iterations', type=int, default=3)
    args = parser.parse_args()
    repo = Path(__file__).resolve().parent.parent
    previous, work, profiler = args.previous.resolve(), args.work.resolve(), args.profiler.resolve()
    root, index = previous / args.suite, previous / (args.suite + '-index')
    old = previous / (args.suite + '-results')
    out = work / args.suite
    out.mkdir(parents=True, exist_ok=False)
    expected_dir = out / 'expected'
    expected_dir.mkdir()
    old_meta = json.loads((old / 'metadata.json').read_text())
    assert sha(index / 'manifest.bin') == old_meta['manifest_sha256'], 'prior index changed'
    source_paths = [repo / 'Cargo.toml', repo / 'Cargo.lock', *sorted((repo / 'src').glob('*.rs')),
                    repo / 'benches/masked_cover_profile.rs', Path(__file__),
                    *sorted((repo / 'benches/support').glob('*.rs')), repo / 'tests/masked_cover.rs']
    metadata = dict(started_utc=datetime.now(timezone.utc).isoformat(), platform=platform.platform(),
        corpus=args.suite, root=str(root), index=str(index), manifest_sha256=sha(index / 'manifest.bin'),
        previous_summary_sha256=sha(old / 'summary.json'), profiler_sha256=sha(profiler),
        source_sha256={str(p.relative_to(repo)): sha(p) for p in source_paths},
        iterations=args.iterations, scan_iterations=args.scan_iterations, warmup=2,
        scan_queries=sorted(SCAN_QUERIES[args.suite]), logical_cpus=os.cpu_count(),
        environment={k: os.environ.get(k) for k in ('RAYON_NUM_THREADS', 'LANG', 'LC_ALL')})
    def dump(name, data):
        (out / name).write_text(json.dumps(data, indent=2) + '\n')
    dump('metadata.json', metadata)
    rows = json.loads((old / 'summary.json').read_text())
    random.Random(20260914).shuffle(rows)
    results, commands = [], []
    for row in rows:
        name = row['id']
        prior_report = json.loads((old / (name + '.json')).read_text())
        expected = prior_report['matches']
        expected_sha = hashlib.sha256(json.dumps(expected, sort_keys=True).encode()).hexdigest()
        assert all(p['sha256'] == expected_sha for p in row['parity'].values())
        expected_file = expected_dir / (name + '.json')
        expected_file.write_text(json.dumps(expected) + '\n')
        output = out / (name + '.json')
        command = [str(profiler), '--root', str(root), '--index-dir', str(index), '--pattern', row['pattern'],
                   *row['flags'], '--expected', str(expected_file), '--output', str(output),
                   '--iterations', str(args.iterations), '--scan-iterations',
                   str(args.scan_iterations if name in SCAN_QUERIES[args.suite] else 0)]
        commands.append(command)
        print(args.suite, name, 'start', flush=True)
        subprocess.run(command, cwd=repo, check=True)
        report = json.loads(output.read_text())
        assert report['production_baseline_equivalent'] and report['expected_counts_verified']
        assert report['matched_files'] == len(expected)
        summary = summarize(report)
        results.append(dict(id=name, pattern=row['pattern'], flags=row['flags'], expected_sha256=expected_sha,
                            expected_file_sha256=sha(expected_file), summary=summary))
        dump('summary.json', results)
        dump('commands.json', commands)
        print(args.suite, name, 'posting reads', [summary[m]['posting_reads'] for m in MODES],
              'candidates', [summary[m]['candidates'] for m in MODES], flush=True)
    assert sha(index / 'manifest.bin') == metadata['manifest_sha256']
    metadata['finished_utc'] = datetime.now(timezone.utc).isoformat()
    dump('metadata.json', metadata)

if __name__ == '__main__':
    main()
