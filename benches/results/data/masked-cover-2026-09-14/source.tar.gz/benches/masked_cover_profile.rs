//! Compare physical posting reads with masks integrated into covering/execution.
#![allow(dead_code, unused_imports)]
#[path = "../src/build.rs"]
mod build;
#[path = "../src/compaction.rs"]
mod compaction;
#[path = "../src/git_state.rs"]
mod git_state;
#[path = "../src/index.rs"]
mod index;
#[path = "../src/manifest.rs"]
mod manifest;
#[path = "support/masked_cover.rs"]
mod masked_cover;
#[path = "support/gram_source.rs"]
mod ngram;
#[path = "support/literal_source.rs"]
mod query;
#[path = "../src/segment.rs"]
mod segment;
mod search {
    include!("../src/search.rs");
    pub fn original(
        index: &index::DiskIndex,
        strategies: &[query::GramGroup],
    ) -> Result<(Vec<u32>, Vec<u32>)> {
        let mut keys = Vec::new();
        let ids = intersect_postings(strategies, |h| {
            keys.push(h);
            index.postings(h)
        })?
        .map(|s| s.into_iter().collect())
        .unwrap_or_else(|| index.all_document_ids());
        Ok((ids, keys))
    }
    pub fn count(regex: &Regex, bytes: &[u8]) -> usize {
        match_file(
            regex,
            bytes,
            Path::new(""),
            &Options {
                ignore_case: false,
                fixed_strings: false,
                files_with_matches: false,
                count: true,
                max_count: None,
                no_refresh: true,
            },
        )
        .1
    }
}
use anyhow::{Context, Result, ensure};
use clap::Parser;
use masked_cover::{Mode, Plan, Stats, Term};
use rayon::prelude::*;
use regex::bytes::{Regex, RegexBuilder};
use serde::Serialize;
use std::{
    collections::{BTreeMap, BTreeSet, HashMap},
    fs,
    path::PathBuf,
    time::Instant,
};

#[derive(Parser)]
struct Args {
    #[arg(long)]
    root: PathBuf,
    #[arg(long)]
    index_dir: PathBuf,
    #[arg(long)]
    pattern: String,
    #[arg(short = 'i')]
    ignore_case: bool,
    #[arg(short = 'F')]
    fixed_strings: bool,
    /// Previously verified complete path -> matching-line-count map.
    #[arg(long)]
    expected: PathBuf,
    #[arg(long)]
    output: PathBuf,
    #[arg(long, default_value_t = 9)]
    iterations: usize,
    #[arg(long, default_value_t = 2)]
    warmup: usize,
    /// Optional paired read+match timing rounds; validation always scans once.
    #[arg(long, default_value_t = 0)]
    scan_iterations: usize,
    #[arg(long, hide = true)]
    bench: bool,
}
fn ms(start: Instant) -> f64 {
    start.elapsed().as_secs_f64() * 1000.0
}

struct Masks {
    slots: HashMap<[u8; 3], usize>,
    tables: Vec<HashMap<u32, u8>>,
    prepare_ms: f64,
    source_bytes: u64,
    documents: usize,
}
impl Masks {
    fn prepare(index: &index::DiskIndex, plans: &[Plan]) -> Result<Self> {
        let start = Instant::now();
        let mut keys = BTreeMap::new();
        for term in plans.iter().flatten().flatten().flatten() {
            if let Some(q) = term.next {
                keys.insert(<[u8; 3]>::try_from(&q[..3]).unwrap(), term.hash);
            }
        }
        let keys: Vec<_> = keys.into_iter().collect();
        let mut work: BTreeMap<u32, Vec<usize>> = BTreeMap::new();
        for (slot, (_, hash)) in keys.iter().enumerate() {
            // Include ALL documents in each physical posting, including ones
            // outside the old candidate set; a coarser cover can admit them.
            for id in index.postings(*hash)? {
                work.entry(id).or_default().push(slot);
            }
        }
        let records: Vec<_> = work
            .par_iter()
            .map(|(&id, slots)| -> Result<_> {
                let doc = &index.manifest.documents[id as usize];
                let bytes = fs::read(index.manifest.root.join(&doc.path))?;
                ensure!(
                    bytes.len() as u64 == doc.len,
                    "source changed: {}",
                    doc.path.display()
                );
                Ok((
                    id,
                    slots
                        .iter()
                        .map(|&s| (s, masked_cover::document_mask(&bytes, &keys[s].0)))
                        .collect::<Vec<_>>(),
                ))
            })
            .collect::<Result<_>>()?;
        let mut tables = vec![HashMap::new(); keys.len()];
        for (id, values) in records {
            for (slot, mask) in values {
                tables[slot].insert(id, mask);
            }
        }
        let source_bytes = work
            .keys()
            .map(|&id| index.manifest.documents[id as usize].len)
            .sum();
        Ok(Self {
            slots: keys
                .iter()
                .enumerate()
                .map(|(i, (key, _))| (*key, i))
                .collect(),
            tables,
            prepare_ms: ms(start),
            source_bytes,
            documents: work.len(),
        })
    }
    fn accepts(&self, t: Term, id: u32) -> bool {
        let q = t.next.unwrap();
        let key: [u8; 3] = q[..3].try_into().unwrap();
        let mask = self.tables[self.slots[&key]]
            .get(&id)
            .expect("missing prepared posting metadata");
        mask & masked_cover::next_bit(q[3]) != 0
    }
}

#[derive(Serialize)]
struct QuerySample {
    mode: Mode,
    query_ms: f64,
    candidates: usize,
    stats: Stats,
}
fn execute(
    index: &index::DiskIndex,
    plan: &Plan,
    masks: &Masks,
    mode: Mode,
) -> Result<(Vec<u32>, QuerySample)> {
    let start = Instant::now();
    let (ids, stats) = masked_cover::execute(
        plan,
        |h| index.postings(h),
        |t, id| masks.accepts(t, id),
        query::MAX_INDEX_LOOKUPS,
    )?;
    let ids: Vec<_> = ids
        .map(|s| s.into_iter().collect())
        .unwrap_or_else(|| index.all_document_ids());
    let sample = QuerySample {
        mode,
        query_ms: ms(start),
        candidates: ids.len(),
        stats,
    };
    Ok((ids, sample))
}

#[derive(Serialize)]
struct ScanSample {
    mode: Mode,
    scan_wall_ms: f64,
    read_worker_ms: f64,
    match_worker_ms: f64,
    false_positive_read_worker_ms: f64,
    false_positive_match_worker_ms: f64,
}
fn scan(
    index: &index::DiskIndex,
    ids: &[u32],
    regex: &Regex,
    mode: Mode,
) -> Result<(Vec<(u32, usize)>, ScanSample)> {
    let start = Instant::now();
    let files: Vec<_> = ids
        .par_iter()
        .map_init(
            || regex.clone(),
            |regex, &id| -> Result<_> {
                let doc = &index.manifest.documents[id as usize];
                let path = index.manifest.root.join(&doc.path);
                let read = Instant::now();
                let bytes =
                    fs::read(&path).with_context(|| format!("reading {}", path.display()))?;
                let read_ms = ms(read);
                ensure!(bytes.len() as u64 == doc.len, "source changed");
                let matching = Instant::now();
                let count = search::count(regex, &bytes);
                Ok((id, count, read_ms, ms(matching)))
            },
        )
        .collect::<Result<_>>()?;
    let mut sample = ScanSample {
        mode,
        scan_wall_ms: ms(start),
        read_worker_ms: 0.,
        match_worker_ms: 0.,
        false_positive_read_worker_ms: 0.,
        false_positive_match_worker_ms: 0.,
    };
    let mut counts = Vec::new();
    for (id, count, read, matching) in files {
        sample.read_worker_ms += read;
        sample.match_worker_ms += matching;
        if count == 0 {
            sample.false_positive_read_worker_ms += read;
            sample.false_positive_match_worker_ms += matching;
        } else {
            counts.push((id, count));
        }
    }
    Ok((counts, sample))
}

#[derive(Serialize)]
struct CandidateSummary {
    mode: Mode,
    candidates: usize,
    false_positive_files: usize,
    candidate_bytes: u64,
    false_positive_bytes: u64,
    added_vs_baseline: usize,
    removed_vs_baseline: usize,
    added_vs_old_cover_mask: usize,
    removed_vs_old_cover_mask: usize,
    planned_keys: usize,
    planned_predicates: usize,
}
#[derive(Serialize)]
struct Report {
    pattern: String,
    ignore_case: bool,
    fixed_strings: bool,
    indexed_files: usize,
    matched_files: usize,
    matched_lines: usize,
    index_load_ms: f64,
    plan_ms: Vec<f64>,
    plans: Vec<Plan>,
    mask_prepare_ms: f64,
    mask_source_bytes: u64,
    mask_documents: usize,
    mask_entries: usize,
    summaries: Vec<CandidateSummary>,
    query_samples: Vec<QuerySample>,
    scan_samples: Vec<ScanSample>,
    validation_union_candidates: usize,
    validation_scan_ms: f64,
    production_baseline_equivalent: bool,
    expected_counts_verified: bool,
}

fn main() -> Result<()> {
    let args = Args::parse();
    ensure!(args.iterations > 0, "iterations must be positive");
    let start = Instant::now();
    let index = index::load(&args.root, Some(&args.index_dir))?;
    let index_load_ms = ms(start);
    let expected: BTreeMap<String, usize> = serde_json::from_slice(&fs::read(&args.expected)?)?;
    let expected_ids: BTreeMap<u32, usize> = index
        .manifest
        .documents
        .iter()
        .enumerate()
        .filter_map(|(id, d)| {
            expected
                .get(d.path.to_string_lossy().as_ref())
                .map(|&c| (id as u32, c))
        })
        .collect();
    ensure!(
        expected_ids.len() == expected.len(),
        "reference contains unindexed paths"
    );
    let pattern = if args.fixed_strings {
        regex::escape(&args.pattern)
    } else {
        args.pattern.clone()
    };
    let regex = RegexBuilder::new(&pattern)
        .case_insensitive(args.ignore_case)
        .multi_line(true)
        .build()?;
    let modes = [Mode::Baseline, Mode::OldCoverMask, Mode::MaskedCover];
    let mut plans = Vec::new();
    let mut plan_ms = Vec::new();
    for mode in modes {
        let start = Instant::now();
        let literals = if args.fixed_strings && !args.ignore_case {
            vec![vec![args.pattern.as_bytes().to_vec()]]
        } else {
            query::literals(&pattern, args.ignore_case)?
        };
        plans.push(masked_cover::plan(&literals, mode));
        plan_ms.push(ms(start));
    }
    let masks = Masks::prepare(&index, &plans)?;
    let actual_plan = if args.fixed_strings && !args.ignore_case {
        query::fixed_strategy(args.pattern.as_bytes())
    } else {
        query::literal_strategies(&pattern, args.ignore_case)?
    };
    let (actual_ids, actual_keys) = search::original(&index, &actual_plan)?;
    let mut mode_ids = Vec::new();
    for (slot, mode) in modes.iter().copied().enumerate() {
        let (ids, sample) = execute(&index, &plans[slot], &masks, mode)?;
        if slot == 0 {
            ensure!(
                ids == actual_ids && sample.stats.loaded_keys == actual_keys,
                "baseline differs from production"
            );
        }
        for id in expected_ids.keys() {
            ensure!(
                ids.binary_search(id).is_ok(),
                "{mode:?} dropped matched document {id}"
            );
        }
        mode_ids.push(ids);
    }
    let union: BTreeSet<_> = mode_ids.iter().flatten().copied().collect();
    let (counts, validation) = scan(
        &index,
        &union.iter().copied().collect::<Vec<_>>(),
        &regex,
        Mode::Baseline,
    )?;
    ensure!(
        counts.into_iter().collect::<BTreeMap<_, _>>() == expected_ids,
        "current files differ from verified reference"
    );
    let baseline: BTreeSet<_> = mode_ids[0].iter().copied().collect();
    let old_mask: BTreeSet<_> = mode_ids[1].iter().copied().collect();
    let summaries = modes
        .iter()
        .copied()
        .enumerate()
        .map(|(slot, mode)| {
            let ids = &mode_ids[slot];
            let terms: Vec<_> = plans[slot].iter().flatten().flatten().copied().collect();
            CandidateSummary {
                mode,
                candidates: ids.len(),
                false_positive_files: ids.len() - expected_ids.len(),
                candidate_bytes: ids
                    .iter()
                    .map(|&id| index.manifest.documents[id as usize].len)
                    .sum(),
                false_positive_bytes: ids
                    .iter()
                    .filter(|id| !expected_ids.contains_key(id))
                    .map(|&id| index.manifest.documents[id as usize].len)
                    .sum(),
                added_vs_baseline: ids.iter().filter(|id| !baseline.contains(id)).count(),
                removed_vs_baseline: baseline
                    .iter()
                    .filter(|id| ids.binary_search(id).is_err())
                    .count(),
                added_vs_old_cover_mask: ids.iter().filter(|id| !old_mask.contains(id)).count(),
                removed_vs_old_cover_mask: old_mask
                    .iter()
                    .filter(|id| ids.binary_search(id).is_err())
                    .count(),
                planned_keys: terms.iter().map(|t| t.hash).collect::<BTreeSet<_>>().len(),
                planned_predicates: terms.iter().copied().collect::<BTreeSet<_>>().len(),
            }
        })
        .collect();
    let mut query_samples = Vec::new();
    for round in 0..args.warmup + args.iterations {
        for step in 0..3 {
            let slot = (round + step) % 3;
            let (ids, sample) = execute(&index, &plans[slot], &masks, modes[slot])?;
            ensure!(ids == mode_ids[slot], "unstable candidates");
            if round >= args.warmup {
                query_samples.push(sample);
            }
        }
    }
    let mut scan_samples = Vec::new();
    if args.scan_iterations > 0 {
        for round in 0..args.warmup + args.scan_iterations {
            for step in 0..3 {
                let slot = (round + step) % 3;
                let (counts, sample) = scan(&index, &mode_ids[slot], &regex, modes[slot])?;
                ensure!(
                    counts.into_iter().collect::<BTreeMap<_, _>>() == expected_ids,
                    "scan results changed"
                );
                if round >= args.warmup {
                    scan_samples.push(sample);
                }
            }
        }
    }
    let report = Report {
        pattern: args.pattern,
        ignore_case: args.ignore_case,
        fixed_strings: args.fixed_strings,
        indexed_files: index.all_document_ids().len(),
        matched_files: expected.len(),
        matched_lines: expected.values().sum(),
        index_load_ms,
        plan_ms,
        plans,
        mask_prepare_ms: masks.prepare_ms,
        mask_source_bytes: masks.source_bytes,
        mask_documents: masks.documents,
        mask_entries: masks.tables.iter().map(HashMap::len).sum(),
        summaries,
        query_samples,
        scan_samples,
        validation_union_candidates: union.len(),
        validation_scan_ms: validation.scan_wall_ms,
        production_baseline_equivalent: true,
        expected_counts_verified: true,
    };
    fs::write(args.output, serde_json::to_vec_pretty(&report)?)?;
    Ok(())
}
