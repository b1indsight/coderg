#[allow(dead_code)]
#[path = "../src/manifest.rs"]
mod manifest_format;

use std::{
    fs,
    path::Path,
    process::{Command, Output},
};

fn run(root: &Path, args: &[&str]) -> Output {
    let output = Command::new(env!("CARGO_BIN_EXE_coderg"))
        .args(args)
        .arg(root)
        .output()
        .unwrap();
    assert!(
        output.status.success(),
        "{args:?}: {}",
        String::from_utf8_lossy(&output.stderr)
    );
    output
}

fn manifest(root: &Path) -> manifest_format::Manifest {
    manifest_format::read(&root.join(".coderg-index/manifest.bin")).unwrap()
}

fn git(root: &Path, args: &[&str]) {
    let output = Command::new("git")
        .current_dir(root)
        .args(args)
        .output()
        .unwrap();
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
}

fn init_git(root: &Path) {
    git(root, &["init"]);
    git(root, &["config", "user.name", "Coderg Test"]);
    git(root, &["config", "user.email", "coderg@example.invalid"]);
}

fn matched(root: &Path, pattern: &str, expected: &[&str]) {
    let output = Command::new(env!("CARGO_BIN_EXE_coderg"))
        .args(["search", "--no-refresh", "-F", "-l", pattern])
        .arg(root)
        .output()
        .unwrap();
    assert_eq!(
        output.status.code(),
        Some(if expected.is_empty() { 1 } else { 0 }),
        "{pattern}: {}",
        String::from_utf8_lossy(&output.stderr)
    );
    let text = String::from_utf8(output.stdout).unwrap();
    let mut paths: Vec<_> = text.lines().collect();
    paths.sort_unstable();
    assert_eq!(paths, expected, "{pattern}");
}

#[test]
fn changed_head_with_dirty_worktree_updates_both_committed_and_uncommitted_files() {
    let root = tempfile::tempdir().unwrap();
    init_git(root.path());
    fs::write(root.path().join("x.txt"), "base x\n").unwrap();
    fs::write(root.path().join("y.txt"), "base y\n").unwrap();
    git(root.path(), &["add", "x.txt", "y.txt"]);
    git(root.path(), &["commit", "-m", "base"]);
    run(root.path(), &["index"]);
    let base = manifest(root.path()).segments[0].clone();
    fs::write(root.path().join("x.txt"), "committed unique needle\n").unwrap();
    git(root.path(), &["add", "x.txt"]);
    git(root.path(), &["commit", "-m", "new x"]);
    fs::write(root.path().join("y.txt"), "dirty unique needle\n").unwrap();
    run(root.path(), &["search", "unique needle"]);
    matched(root.path(), "committed unique", &["x.txt"]);
    matched(root.path(), "dirty unique", &["y.txt"]);
    assert_eq!(manifest(root.path()).segments[0], base);
    assert!(!root.path().join(".coderg-index/manifests").exists());
}

#[test]
fn many_updates_merge_middle_segments_without_rebuilding_the_base() {
    let root = tempfile::tempdir().unwrap();
    for i in 0..30 {
        fs::write(
            root.path().join(format!("{i:02}.txt")),
            format!("base record {i}\n"),
        )
        .unwrap();
    }
    run(root.path(), &["index"]);
    let base = manifest(root.path()).segments[0].clone();
    let base_lookup = fs::read(root.path().join(".coderg-index").join(&base.lookup)).unwrap();
    let mut merges = 0;
    for i in 0..24 {
        fs::write(
            root.path().join(format!("{i:02}.txt")),
            format!("updated unique record {i:02}\n"),
        )
        .unwrap();
        let result = run(root.path(), &["search", "updated unique"]);
        merges += usize::from(String::from_utf8_lossy(&result.stderr).contains("compacted"));
        let snapshot = manifest(root.path());
        assert_eq!(snapshot.segments[0], base);
        assert!(snapshot.segments.len() <= 9);
        for j in 0..=i {
            matched(
                root.path(),
                &format!("updated unique record {j:02}"),
                &[&format!("{j:02}.txt")],
            );
        }
    }
    assert!(merges > 0);
    assert_eq!(
        fs::read(root.path().join(".coderg-index").join(&base.lookup)).unwrap(),
        base_lookup
    );
    // A file that has already moved through a merged M segment is edited again.
    fs::write(root.path().join("00.txt"), "edited after merge\n").unwrap();
    run(root.path(), &["search", "edited after merge"]);
    run(root.path(), &["compact"]);
    matched(root.path(), "edited after merge", &["00.txt"]);
    matched(root.path(), "updated unique record 00", &[]);
    assert_eq!(manifest(root.path()).segments.len(), 2);
}

#[test]
fn deletion_binary_rename_restore_and_compaction_preserve_current_versions() {
    let root = tempfile::tempdir().unwrap();
    for (path, content) in [
        ("a.txt", "base alpha"),
        ("b.txt", "base beta"),
        ("c.txt", "base gamma"),
    ] {
        fs::write(root.path().join(path), content).unwrap();
    }
    run(root.path(), &["index"]);
    fs::write(root.path().join("a.txt"), "changed alpha").unwrap();
    run(root.path(), &["search", "changed alpha"]);
    fs::remove_file(root.path().join("a.txt")).unwrap();
    fs::write(root.path().join("b.txt"), b"\0binary beta").unwrap();
    fs::rename(root.path().join("c.txt"), root.path().join("renamed.txt")).unwrap();
    run(root.path(), &["search", "base gamma"]);
    run(root.path(), &["compact"]);
    matched(root.path(), "alpha", &[]);
    matched(root.path(), "beta", &[]);
    matched(root.path(), "gamma", &["renamed.txt"]);
    fs::write(root.path().join("a.txt"), "base alpha").unwrap();
    fs::write(root.path().join("b.txt"), "restored beta").unwrap();
    run(root.path(), &["search", "restored beta"]);
    let before = fs::read(root.path().join(".coderg-index/manifest.bin")).unwrap();
    run(root.path(), &["compact", "--dry-run"]);
    assert_eq!(
        before,
        fs::read(root.path().join(".coderg-index/manifest.bin")).unwrap()
    );
    // Compaction must use the already-indexed records, even if all source files
    // disappear while maintenance runs. Restore them before no-refresh queries.
    let files = [
        ("a.txt", "base alpha"),
        ("b.txt", "restored beta"),
        ("renamed.txt", "base gamma"),
    ];
    for (path, _) in files {
        fs::remove_file(root.path().join(path)).unwrap();
    }
    run(root.path(), &["compact"]);
    for (path, content) in files {
        fs::write(root.path().join(path), content).unwrap();
    }
    assert_eq!(manifest(root.path()).segments.len(), 2);
    matched(root.path(), "base alpha", &["a.txt"]);
    matched(root.path(), "restored beta", &["b.txt"]);
    matched(root.path(), "base gamma", &["renamed.txt"]);
}

#[test]
fn concurrent_refreshes_publish_one_content_update() {
    let root = tempfile::tempdir().unwrap();
    fs::write(root.path().join("source.txt"), "initial\n").unwrap();
    run(root.path(), &["index"]);
    let generation = manifest(root.path()).generation;
    fs::write(root.path().join("source.txt"), "concurrent unique needle\n").unwrap();
    let children: Vec<_> = (0..6)
        .map(|_| {
            Command::new(env!("CARGO_BIN_EXE_coderg"))
                .args(["search", "concurrent unique"])
                .arg(root.path())
                .stdout(std::process::Stdio::piped())
                .stderr(std::process::Stdio::piped())
                .spawn()
                .unwrap()
        })
        .collect();
    for child in children {
        let output = child.wait_with_output().unwrap();
        assert!(
            output.status.success(),
            "{}",
            String::from_utf8_lossy(&output.stderr)
        );
        assert!(String::from_utf8_lossy(&output.stdout).contains("concurrent unique needle"));
    }
    let snapshot = manifest(root.path());
    assert_eq!(snapshot.generation, generation + 1);
    assert_eq!(snapshot.segments.len(), 2);
}

#[test]
fn obsolete_full_compaction_flag_is_rejected() {
    let root = tempfile::tempdir().unwrap();
    let output = Command::new(env!("CARGO_BIN_EXE_coderg"))
        .args(["compact", "--full"])
        .arg(root.path())
        .output()
        .unwrap();
    assert_eq!(output.status.code(), Some(2));
    assert!(!root.path().join(".coderg-index").exists());
}
